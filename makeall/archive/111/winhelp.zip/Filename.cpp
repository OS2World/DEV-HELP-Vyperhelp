/***************************************************************************
 * File...... Filename.cpp
 * Author.... Mat
 * Date...... 12/21/95
 *
 * Implementation of Filename, which is derived from IString.
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/

// OS/2
#define INCL_DOSFILEMGR
#define INCL_DOSMISC
#include <os2.h>

// Standard C
#include <stdio.h>
#include <stdlib.h>

// OpenClass
#include <iexcept.hpp>


#include "Filename.hpp"


unsigned int Filename::_maxPathLength = computeMaxPathLength();


Filename::Filename( const IString & string ):
    IString( string )
{}


Filename::Filename( const char * string ):
    IString( string )
{}


Filename::Filename( AutoName autoname )
{
  // temporary is currently the only option
  // create a temporary file with a unique name
  char tempname[L_tmpnam];
  char * result = tmpnam( tempname );
  if ( result )
    overlayWith( tempname );
  else
    ICLibErrorInfo::throwCLibError("tmpnam", IEXCEPTION_LOCATION() );
}


// case-insensitive compare
int Filename::operator==( const Filename & filename ) const
{
  return upperCase( filename ) == upperCase( *this );
}

int Filename::operator!=( const Filename & filename ) const
{
  return ! operator==( filename );
}


/***************************************************************************
 * Procedure.. Filename::locateOnPath
 * Author..... Mat
 * Date....... 12/21/95
 *
 * Search the specified path for the file.  If found, prepend the path and
 * return true.  checkCurrentFirst is true if the current directory should
 * be checked first.
 ***************************************************************************/
Boolean Filename::locateOnPath( const IString & path, Boolean checkCurrentFirst )
{
  // allocate buffer from stack for result
  char * pathbuf = (char *) _alloca( _maxPathLength );

  // search the path
  APIRET rc = DosSearchPath(
      checkCurrentFirst? SEARCH_CUR_DIRECTORY: 0,
      path, *this, pathbuf, _maxPathLength );
  if ( rc ) {
    return false;
  }
  overlayWith( pathbuf );  // save full filename
  return true;
}


/***************************************************************************
 * Procedure.. Filename::locateOnStandardPath
 * Author..... Mat
 * Date....... 12/21/95
 *
 * Search a standard path for the file.  If found, prepend the path and
 * return true.  checkCurrentFirst is true if the current directory should
 * be checked first.
 ***************************************************************************/
Boolean Filename::locateOnStandardPath( StandardPath path, Boolean checkCurrentFirst )
{
  // get path from the environment
  char * pathString = 0;
  switch ( path )
  {
    case include:
      pathString = getenv( "INCLUDE" );
      break;
    case tabpath:
      pathString = getenv( "TABPATH" );
      break;
  }

  // create empty path if necessary
  if ( ! pathString )
  {
    if ( checkCurrentFirst )
      pathString = "";  // empty path list, still need to check current dir
    else
      return false;     // didn't find it
  }

  return locateOnPath( pathString, checkCurrentFirst );
}


/***************************************************************************
 * Procedure.. Filename::fullPath()
 * Author..... Mat
 * Date....... 12/28/95
 *
 * Returns the fully-qualified filename.
 ***************************************************************************/
Filename Filename::fullPath() const
{
  // allocate buffer from stack for result
  char * pathbuf = (char *) _alloca( _maxPathLength );

  // call C run-time
  if ( _fullpath( pathbuf, *this, _maxPathLength ) == NULL ) {
    // function failed!
    ITHROWCLIBERROR( "_fullpath",
        IErrorInfo::invalidRequest, IException::recoverable );
  } /* endif */

  // return the result
  return IString( pathbuf );
}


/***************************************************************************
 * Procedure.. Filename::extension()
 * Author..... Mat
 * Date....... 12/2/97
 *
 * Returns the extension of the filename (with leading period).
 ***************************************************************************/
IString Filename::extension() const
{
  char ext[ _MAX_EXT ];
  _splitpath( fullPath(), NULL, NULL, NULL, ext );
  return IString( ext );
}


/***************************************************************************
 * Procedure.. Filename::base()
 * Author..... Mat
 * Date....... 12/28/95
 *
 * Returns the base name portion of the filename.
 ***************************************************************************/
IString Filename::base() const
{
  char fname[ _MAX_FNAME ];
  _splitpath( fullPath(), NULL, NULL, fname, NULL );
  return IString( fname );
}


/***************************************************************************
 * Procedure.. Filename::name()
 * Author..... Mat
 * Date....... 12/2/97
 *
 * Returns the base filename plus extension.
 ***************************************************************************/
Filename Filename::name() const
{
  char fname[ _MAX_FNAME ];
  char ext[ _MAX_EXT ];
  _splitpath( fullPath(), NULL, NULL, fname, ext );
  return IString( fname ) + IString( ext );
}


/***************************************************************************
 * Procedure.. Filename::fullBase()
 * Author..... Mat
 * Date....... 3/5/96
 *
 * Retunrs drive + dir + base portion of filename.
 ***************************************************************************/
IString Filename::fullBase() const
{
  char drive[ _MAX_DRIVE ];
  char dir[ _MAX_DIR ];
  char fname[ _MAX_FNAME ];
  _splitpath( fullPath(), drive, dir, fname, NULL );
  return IString( drive ) + IString( dir ) + IString( fname );
}


/***************************************************************************
 * Procedure.. Filename::dir()
 * Author..... Mat
 * Date....... 3/5/96
 *
 * Returns the drive + directory (with trailing backslash)
 ***************************************************************************/
IString Filename::dir() const
{
  char drive[ _MAX_DRIVE ];
  char dir[ _MAX_DIR ];
  _splitpath( fullPath(), drive, dir, NULL, NULL );
  return IString( drive ) + IString( dir );
}


/***************************************************************************
 * Procedure.. Filename::maxPathLength
 * Author..... Mat
 * Date....... 12/26/95
 *
 * Return system-wide constant max path\file length (including 0 terminator.
 ***************************************************************************/
unsigned int Filename::maxPathLength()
{
  return _maxPathLength;
}



/***************************************************************************
 * Procedure.. FilenameList::FilenameList
 * Author..... Mat
 * Date....... 12/26/95
 *
 * Constructor for FilenameList
 ***************************************************************************/
FilenameList::FilenameList( INumber numberOfElements ):
    IEqualitySequence< Filename >( numberOfElements )
{}


/***************************************************************************
 * Procedure.. FilenameList::locateFullPath
 * Author..... Mat
 * Date....... 12/26/95
 *
 * Assuming that filename is a filename without a path, this function will
 * search the filename list for a match.  If a match is found, filename is
 * modified to include the entire filespec found and true is returned.
 ***************************************************************************/
Boolean FilenameList::locateFullPath( Filename & filename ) const
{
  // check every filename in the list for a match
  Cursor cursor( *this );
  forCursor( cursor )
  {
    if ( cursor.element().name() == filename )
    {
      // found it!  return entry from list
      filename = cursor.element();
      return true;
    }
  }

  return false;  // coudn't find it!
}


/***************************************************************************
 * Procedure.. Filename::computeMaxPathLength
 * Author..... Mat
 * Date....... 12/26/95
 *
 * sets system-wide max path\file length
 ***************************************************************************/
unsigned int Filename::computeMaxPathLength()
{
  // get max path\file length or use default of 255
  ULONG maxPathLength = 255;
  DosQuerySysInfo( QSV_MAX_PATH_LENGTH, QSV_MAX_PATH_LENGTH,
      &maxPathLength, sizeof( maxPathLength ) );
  return ++maxPathLength;  // allow for zero-terminator
}


/***************************************************************************
 * Procedure.. Filename::remove
 * Author..... Mat
 * Date....... 1/15/98
 *
 * Remove (delete) this file.
 ***************************************************************************/
void Filename::remove()
{
  ::remove( *this );
}

