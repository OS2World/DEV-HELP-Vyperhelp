/***************************************************************************
 * File...... EnhancedYacc.hpp
 * Author.... Mat
 * Date...... 12/21/95
 *
 * This subclass of SSYacc adds some common helper functions
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/
#ifndef ENHANCED_YACC
#define ENHANCED_YACC

// OpenClass
#include <istring.hpp>

// Visual Parse++
#include <ssyacc.hpp>
#include <sslex.hpp>



/***************************************************************************
 * Class...... EnhancedYacc
 * Author..... Mat
 * Date....... 12/21/95
 *
 * Adds helper functions to SSYacc for use during the reduce() function.
 ***************************************************************************/
class EnhancedYacc : public SSYacc
{
  public:
    // constructors
    SSConstr EnhancedYacc( const IString & tableName, const IString & consumer );

  protected:
    // parsing helper functions
    SSUnsigned32 lexemeAsULong( SSSigned32 n );
    IString      lexemeAsString( SSSigned32 n );

  private:
    SSLex _lex;
};


#endif

