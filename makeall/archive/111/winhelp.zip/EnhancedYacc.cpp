/***************************************************************************
 * File...... EnhancedYacc.cpp
 * Author.... Mat
 * Date...... 12/21/95
 *
 * Implements EnhancedYacc, which adds helper functions to SSYacc.
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/

// Standard C
#include <stdlib.h>

// OpenClass
#include <iexcept.hpp>

// WinHelp
#include "Filename.hpp"
#include "EnhancedYacc.hpp"


/***************************************************************************
 * Procedure.. EnhancedYacc::EnhancedYacc
 * Author..... Mat
 * Date....... 12/21/95
 *
 * The tableName provided is the base part of the filename only.  An LLR
 * extenion is used to get the YaccTable, and a DFA extension is used to
 * get the LexTable.  The environment variable TABPATH is used to search
 * for the table files.
 *
 ***************************************************************************/
EnhancedYacc::EnhancedYacc( const IString & tableName, const IString & consumer )
{
  // locate yacc table
  Filename yaccTable = tableName + ".llr";
  yaccTable.locateOnStandardPath( Filename::tabpath, true );
  setTable( yaccTable );

  // locate lex table
  Filename lexTable = tableName + ".dfa";
  lexTable.locateOnStandardPath( Filename::tabpath, true );
  _lex.setTable( lexTable );
  setLex( _lex );

  // set consumer, if provided
  if ( consumer.length() )
    _lex.setConsumer( consumer );
}


/***************************************************************************
 * Procedure.. EnhancedYacc::lexemeAsULong
 * Author..... Mat
 * Date....... 12/21/95
 *
 * Get the nth lexeme from a reduction and convert it to an unsigned long.
 ***************************************************************************/
SSUnsigned32 EnhancedYacc::lexemeAsULong( SSSigned32 n )
{
  SSYaccStackElement *element = elementFromProduction( n );
  IASSERTSTATE( element != NULL );
  SSLexLexeme *lexeme = element->lexeme();
  IASSERTSTATE( lexeme != NULL );
  // use strtoul instead of lexeme->asUnsigned32() for support of hex and octal
  return strtoul( lexeme->asChar(), NULL, 0 );
}


/***************************************************************************
 * Procedure.. EnhancedYacc::lexemeAsString
 * Author..... Mat
 * Date....... 12/21/95
 *
 * Get the nth lexeme from a reduction and convert it to a string.
 ***************************************************************************/
IString EnhancedYacc::lexemeAsString( SSSigned32 n )
{
  SSYaccStackElement *element = elementFromProduction( n );
  IASSERTSTATE( element != NULL );
  SSLexLexeme *lexeme = element->lexeme();
  IASSERTSTATE( lexeme != NULL );
  return lexeme->asChar();
}


