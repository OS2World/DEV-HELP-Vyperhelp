#include "ftblelement.hpp"

   int const& FontTableElement::getKey() const {return fontnumberKey;}


/***************************************************************************
 * Procedure...... FontTableElement::mapFontfamily
 * Author.... Marco
 * Date...... 12/31/1995
 *
 * maps rtf fontfamily names to FontInfo family names.
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/

FontInfo::Family FontTableElement::mapFontfamily() const
{
  FontInfo::Family familyname;

  switch (fontfamily)
  {
    case FROMAN:
      familyname = FontInfo::roman;
      break;
    case FSWISS:
      familyname = FontInfo::swiss;
      break;
    case FMODERN:
      familyname = FontInfo::mono;
      break;
    default:
      if ( fprq == FIX )
        familyname = FontInfo::mono;
      else
      {
        // use FontInfo to determine family
        FontInfo font( facename );
        familyname = font.family();
      }
      break;
  }
  return familyname;
}

