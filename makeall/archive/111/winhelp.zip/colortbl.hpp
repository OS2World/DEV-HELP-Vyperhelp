/***************************************************************************
 * File...... colortbl.hpp
 * Author.... Marco
 * Date...... 12/31/95
 *
 * Defines structure to hold an rtf colortable entry.
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/
#ifndef COLORTBL_HPP
#define COLORTBL_HPP

#include <icolor.hpp>


class  ColorTableElement
{
   private:
   int colornumberKey;
   IColor   colorentry;

   public:
   ColorTableElement(int cred, int cgreen, int cblue,int cnum);
   IColor getColorentry() const;
   int const& getKey() const;
};

int const& key( ColorTableElement const& ctbl);

#endif
