/***************************************************************************
 * File...... ftblelement.hpp
 * Author.... Marco
 * Date...... 12/31/95
 *
 * Defines structure to hold an rtf font table entry.
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/
#ifndef FTBLELEMENT_HPP
#define FTBLELEMENT_HPP

#include <istring.hpp>

#include "Gin.hpp"


class   FontTableElement
{
   public:
   enum Familyname   {FNIL,FROMAN,FSWISS,FMODERN,FSCRIPT,FDECOR,FTECH,FBIDI};
   enum Charsettype  {ANSI=0,SYMBOL=2};
   enum Fprqtype     {DEFAULT,FIX,VARIABLE};

   FontTableElement(int fnum, int fcodepage, Familyname ffamily, Charsettype fcharset,Fprqtype  ffprq, IString  fdata) :
      fontfamily(ffamily),
      codepage(fcodepage),
      charset(fcharset),
      fprq(ffprq),
      fontnumberKey(fnum),
      facename(fdata),
      altname(0)
      {}

   IString getFacename() const
      {return facename;}
   FontInfo::Family mapFontfamily() const;
   int getCodepage() const
      {return codepage;}
   int const& getKey() const;

   private:
   Familyname     fontfamily;
   int            codepage;
   Charsettype    charset;
   Fprqtype       fprq;
   int            fontnumberKey;
   IString        facename;
   IString        altname;

   };

   inline int const& key (FontTableElement const& ftbl)
      {return ftbl.getKey();}


#endif


