#include "colortbl.hpp"

ColorTableElement::ColorTableElement(int cred, int cgreen, int cblue,int cnum) :
   colorentry(cred,cgreen,cblue),
   colornumberKey(cnum)
{}

int const& ColorTableElement::getKey() const
{return colornumberKey;}

IColor ColorTableElement::getColorentry() const
{return colorentry;}


int const& key( ColorTableElement const& ctbl)
{ return ctbl.getKey();}

