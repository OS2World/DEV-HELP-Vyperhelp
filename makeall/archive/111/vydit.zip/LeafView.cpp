/***************************************************************************
 * File...... LeafView.cpp
 * Author.... Mat
 * Date...... 5/7/96
 *
 * Default implementation of virtual LeafView
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/

// OpenClass
#include <iexcept.hpp>      // IASSERT macros

// TextEditor
#include "SmartText.hpp"
#include "Pen.hpp"
#include "FlowItem.hpp"
#include "LeafView.hpp"


LeafView::LeafView( Item * subject, View * owner ):
    View( subject, owner ),
    _subject( subject )
{}


void LeafView::insertItem( Item * item )
{
  FlowItem * flow = (FlowItem *) _subject->parent();
  flow->insertItem( item, _subject );
}


ViewCursor * LeafView::newLeafCursor( const Boolean wantFirst )
{
  return newCursorToThis();
}


View::FormatChange LeafView::format( Pen & pen )
{
  FormatChange change;

  // set view position
  Boolean positionChanged = setPosition( pen.point().x() );

  // determine extent of the change
  change = View::format( pen );
  if ( change < changeSize && positionChanged )
    change = changeSize;
  return change;
}


IPoint LeafView::position() const
{
  return IPoint( _xPosition, 0 );
}


Boolean LeafView::setPosition( Coord xPosition )
{
  if ( xPosition != _xPosition )
  {
    _xPosition = xPosition;
    return true;
  }
  return false;
}

