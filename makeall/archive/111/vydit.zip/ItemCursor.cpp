/***************************************************************************
 * File...... ItemCursor.cpp
 * Author.... Mat
 * Date...... 5/31/96
 *
 * Implementation of abstract class ItemCursor
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/

#include "ItemCursor.hpp"


// needed to declare virtual destructor!
ItemCursor::~ItemCursor()
{}


