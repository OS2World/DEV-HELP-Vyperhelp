/***************************************************************************
 * File...... VPort.cpp
 * Author.... Mat
 * Date...... 5/16/96
 *
 * Implementation of VPort
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/
#include <itrace.hpp>       // ITRACE macros
#include <iscroll.hpp>      // IScrollBar

#include "vtext.h"
#include "VPort.hpp"


/// need to decide on proper initial size
VPort::VPort( unsigned long windowId, IWindow * owner, FlowItem & flow )
  : IViewPort( windowId, owner, owner, IRectangle(),
        IWindow::visible |
        IViewPort::alwaysHorizontalScrollBar |
        IViewPort::alwaysVerticalScrollBar |
        IViewPort::noViewWindowFill ),
    _editor( WND_PAGE, this, &flow )
{
  // set background color
  setBackgroundColor( IGUIColor( IGUIColor::dialogBgnd ) );

  // setup handlers
  IResizeHandler::handleEventsFor( this );
}


Boolean VPort::windowResize( IResizeEvent &event )
{
  ITRACE_ALL( IString("Current, New, Old Size: ") +
      size().asString() + IString(", ") +
      event.newSize().asString() + IString(", ") +
      event.oldSize().asString() );

  if ( event.newSize().width() != event.oldSize().width() )
  {
    // only need to reformat if width changed
    _editor.resize();
  }

  return false;
}


Coord VPort::visibleWidth() const
{
  return size().width() - verticalScrollBar()->size().width();
}


