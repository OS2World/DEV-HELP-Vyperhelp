/***************************************************************************
 * File...... ItemSmartString.cpp
 * Author.... Mat
 * Date...... 5/7/96
 *
 * Implementation of ItemSmartString.  When an ItemSmartString is created,
 * all whitespace is converted to blank and all non-white is considered
 * to be part of a word.
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/

// Standard C
#include <ctype.h>

// OpenClass
#include <iexcept.hpp>      // IASSERT macros

// TextEditor
#include "FlowItem.hpp"
#include "NewLineItem.hpp"
#include "SpaceItem.hpp"
#include "WordItem.hpp"
#include "ItemSmartString.hpp"


ItemSmartString::ItemSmartString( const IString & string ):
    IString( string )
{
  // convert all whitespace to simple blanks, leave newlines alone
  // does not strip leading/trailing whitespace like IString::space()
  unsigned i, len = length();
  char * buffer = *this;  // get pointer to string buffer
  for ( i = 0; i < len; i++ )
  {
    char c = buffer[i];
    if ( isspace( c ) && c != '\n' )
      buffer[i] = ' ';
    /// is this safe for DBCS?
  }
}

unsigned ItemSmartString::numItems() const
{
  unsigned count = 0;
  unsigned index = 1;

  while ( nextItem( index ) != noItem ) {
    count++;
  } /* endwhile */

  return count;
}


Item * ItemSmartString::createItem( unsigned itemIndex, FlowItem * parent ) const
{
  unsigned  count = 0;
  unsigned  index = 1;  // starting string index
  ItemFound found;
  Item    * item;

  // skip all items before itemIndex
  while ( count < itemIndex ) {
    found = nextItem( index );
    IASSERTSTATE( found != noItem );
    count++;
  } /* endwhile */

  // get this item
  unsigned indexFound = index;
  found = nextItem( index );
  IASSERTSTATE( found != noItem );
  switch ( found )
  {
    case spaceItem:
      item = new SpaceItem( parent );
      break;
    case newLineItem:
      item = new NewLineItem( parent );
      break;
    case wordItem:
      item = new WordItem( parent, subString( indexFound ).word( 1 ) );
      break;
  }

  return item;
}


ItemSmartString::ItemFound ItemSmartString::nextItem( unsigned & index ) const
{
  unsigned len = length();

  // check for end of string
  if ( index > len )
  {
    return noItem;
  }

  // check for space item
  char * buffer = *this;
  switch ( buffer[index-1] )
  {
    case ' ':
      // space
      index++;
      return spaceItem;
    case '\n':
      // newline
      index++;
      return newLineItem;
  }

  // otherwise skip the word item
  index = indexOfAnyOf( " \n", index );
  if ( ! index )
  {
    // last word and no space after
    index = len + 1;
  }
  return wordItem;
}

