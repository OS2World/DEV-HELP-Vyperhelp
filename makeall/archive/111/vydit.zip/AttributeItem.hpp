/***************************************************************************
 * File...... AttributeItem.hpp
 * Author.... Mat
 * Date...... 4/17/97
 *
 * AttributeItem represents a change in a font attribute, such as bold,
 * italic and underline.
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/
#ifndef ATTRIBUTEITEM_HPP
#define ATTRIBUTEITEM_HPP


// OpenClass
#include <istring.hpp>

// TextEditor
#include "Item.hpp"


class AttributeItem: public Item
{
  public:
    // attribute types
    enum Type
    {
      bold,
      italic,
      underline
    };

    // constructor
    AttributeItem( Item * parent, Type type, Boolean isEnabled );

    // accessor
    Type    type() const;
    Boolean isEnabled() const;

    // from Item
    virtual View * newView( View * parent );

    // from IBase
    virtual IString asString() const;

  private:
    Type    _type;
    Boolean _isEnabled;
};


#endif

