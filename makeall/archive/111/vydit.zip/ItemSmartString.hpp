/***************************************************************************
 * File...... ItemSmartString.hpp
 * Author.... Mat
 * Date...... 5/7/96
 *
 * ItemSmartString is an IString which "knows" about Items and is able
 * to parse itself into Items.
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/
#ifndef ITEMSMARTSTRING_HPP
#define ITEMSMARTSTRING_HPP


// OpenClass
#include <istring.hpp>      // IString

// TextEditor
class Item;
class FlowItem;


class ItemSmartString: public IString
{
  public:
    // constructor
    ItemSmartString( const IString & string = IString() );

    // item parser
    unsigned numItems() const;
      // returns the number of Items which can be parsed from the string
    Item   * createItem( unsigned itemIndex, FlowItem * parent ) const;
      // create an Item to represent the nth element (0-based index)

  private:
    // parse helpers
    enum ItemFound {
      noItem,
      spaceItem,
      newLineItem,
      wordItem
    };
    ItemFound nextItem( unsigned & index ) const;
      // starting at string index, look for next item
      // if found, return ItemFound and set new index
      // if not found return "noItem"
      // index is a 1-based IString index
};


#endif

