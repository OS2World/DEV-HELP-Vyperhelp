#ifndef TYPES_HPP
#define TYPES_HPP

// miscellaneous types
typedef long Coord;

#endif
