/***************************************************************************
 * File...... FontInfo.cpp
 * Author.... Mat
 * Date...... 2/20/97
 *
 * Implementation of FontInfo
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// OS/2
#define INCL_PM
#include <os2.h>

// OpenClass
#include <ifont.hpp>        // IFont
#include <igrafctx.hpp>     // IGraphicContext
#include <itrace.hpp>       // ITRACE macros
#include <icursor.h>        // ICursor (for iteration)

// Generator
#include "CodePage.hpp"

// TextEditor
#include "FontInfo.hpp"

// Local data
static const char boldVariant[] = " Bold";
static const char italicVariant[] = " Italic";


FontInfo::FontInfo():
    _pointSize( 0 ),  // 0 = default
    _isVector( false ),
    _isBold( false ),
    _isItalic( false ),
    _isUnderline( false )
{}


FontInfo::FontInfo( const IFont & font ):
    _name( font.name() ),
    _pointSize( font.pointSize() ),
    _isVector( ! font.isBitmap() ),
    _isBold( font.isBold() ),
    _isItalic( font.isItalic() ),
    _isUnderline( font.isUnderscore() )
{
  removeVariants();
}


int FontInfo::operator==( const FontInfo & font ) const
{
  return ( _name        == font._name )
      && ( _pointSize   == font._pointSize )
      && ( _isVector    == font._isVector )
      && ( _isBold      == font._isBold )
      && ( _isItalic    == font._isItalic )
      && ( _isUnderline == font._isUnderline );
}


int FontInfo::operator!=( const FontInfo & font ) const
{
  return ! operator==( font );
}


FontGin::Family FontInfo::family() const
{
  // get family name from OS/2 font metrics
  IGraphicContext context;
  IFont * font = newFont( context );
  Boolean isMono = font->isFixed();
  IString familyName( font->fontmetrics()->szFamilyname );
  delete font;

  // search for specific strings
  if ( isMono )
    return FontGin::mono;
  if ( familyName == "Times New Roman" || familyName == "Tms Rmn" )
    return FontGin::roman;
  if ( familyName == "Helvetica" || familyName == "Helv" )
    return FontGin::swiss;
  return FontGin::system;
}


void FontInfo::resetName()
{
  switch ( family() )
  {
    case FontGin::system:
      _name = IString();  // empty string for default font
      break;
    case FontGin::roman:
      _name = "Times New Roman";
      break;
    case FontGin::swiss:
      _name = "Helvetica";
      break;
    case FontGin::mono:
      _name = "Courier";
      break;
  }
}


void FontInfo::setFont( const IString & name, unsigned long pointSize, Boolean isVector )
{
  _name = name;
  _pointSize = pointSize;
  _isVector = isVector;
  removeVariants();
}


/***************************************************************************
 * Procedure.. FontInfo::newFont
 * Author..... Mat
 * Date....... 2/27/97
 *
 * This method creates an IFont from the FontInfo.  There are problems with
 * IBM's IFont, so you have to be careful how you create them if you want
 * to get proper metrics.  The following was arrived at by trial and error
 * and by inspecting the source to IFont.cpp which was found on DevCon
 * volume 12 at h:\services\vacppcsd\cts304\iocsrc\cppoou3\ifont.cpp
 *
 * If there is a specific font design for Bold or Italic variants,
 * then use that instead of letting it be simulated.
 ***************************************************************************/
IFont * FontInfo::newFont( IGraphicContext & context ) const
{
  // save the context's current font
  IFont contextFont = context.currentFont();

  // set default font name or point size if none specified
  IString name = _name;
  Boolean isVector = _isVector;
  unsigned long pointSize = _pointSize;
  Boolean needDefaultName = ( name.length() == 0 );
  if ( needDefaultName || ! pointSize )
  {
    IFont defaultFont;
    if ( needDefaultName )
    {
      name = defaultFont.name();
      isVector = ! defaultFont.isBitmap();
    }
    if ( ! pointSize )
      pointSize = defaultFont.pointSize();
  }

  // check for a "Bold" variant
  Boolean isBold = _isBold;
  if ( isBold )
  {
    if ( addVariant( name, boldVariant, context ) )
      isBold = false;
  }

  // check for a "Italic" variant
  Boolean isItalic = _isItalic;
  if ( isItalic )
  {
    if ( addVariant( name, italicVariant, context ) )
      isItalic = false;
  }

  // create a font in given presentation space
  IFont * newFont = new IFont( name, pointSize, false, isVector, context.handle() );

  // apply the font attributes
  if ( isBold )
    newFont->setBold( _isBold );
  if ( isItalic )
    newFont->setItalic( _isItalic );
  if ( _isUnderline )
    newFont->setUnderscore( _isUnderline );

  // set name and size again to trigger reloading of metrics and char widths
  newFont->setName( name, context.handle() );
  newFont->setPointSize( pointSize, context.handle() );

  // reset the context's font
  CodePage::setContextFont( context, contextFont );

  return newFont;
}


// returns true if variant exists
Boolean FontInfo::addVariant( IString & name, const IString & variant, const IGraphicContext & context ) const
{
  // create variant name
  IString variantName = name + variant;

  // use cursor to search for match
  IFont::FaceNameCursor faces( IFont::FaceNameCursor::both, context.handle() );
  forCursor( faces )
  {
    if ( variantName == IFont::faceNameAt( faces ) )
    {
      name = variantName;
      return true;
    }
  }

  // no match found!
  return false;
}


void FontInfo::removeVariants()
{
  // remove bold variant and set bold flag instead
  if ( _name.indexOfPhrase( boldVariant ) )
  {
    _name.change( boldVariant, "" );
    _isBold = true;
  }

  // remove italic variant and set italic flag instead
  if ( _name.indexOfPhrase( italicVariant ) )
  {
    _name.change( italicVariant, "" );
    _isItalic = true;
  }
}


void FontInfo::dumpMetrics( IGraphicContext & context ) const
{
#if 0
  IFont * font = newFont( context );
  ITRACE_ALL( font->name() + IString(".") + IString(font->pointSize())
            + IString(": m=") + IString(font->charWidth('m'))
            + IString(", ascender=") + IString(font->maxAscender())
            + IString(", descender=") + IString(font->maxDescender()) );
  delete font;
#endif
}


IString FontInfo::asString() const
{
  return _name + IString(".") + IString(_pointSize);
}


