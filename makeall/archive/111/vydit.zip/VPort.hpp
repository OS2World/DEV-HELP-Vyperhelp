/***************************************************************************
 * File...... vport.hpp
 * Author.... Mat
 * Date...... 5/16/96
 *
 * TextEditor ViewPort: allows scrolling of Editor edit window.
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/
#ifndef VPORT_HPP
#define VPORT_HPP

// OpenClass
#include <ivport.hpp>       // IViewPort
#include <isizehdr.hpp>     // IResizeHandler

// TextEditor
#include "vtext.h"
#include "Editor.hpp"
class FlowItem;


class VPort: public IViewPort, public IResizeHandler
{
  public:
    // constructor
    VPort( unsigned long windowId, IWindow * owner, FlowItem & flow );

    // properties
    Coord visibleWidth() const;

    // IResizeHandler
    virtual Boolean windowResize( IResizeEvent &event );

  private:
    Editor _editor;
};

#endif
