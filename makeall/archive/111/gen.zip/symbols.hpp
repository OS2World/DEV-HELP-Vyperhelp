/***************************************************************************
 * File...... symbols.hpp
 * Author.... Mat
 * Date...... 9/26/95
 *
 * This file enumerates all acceptable symbol values.  The list was compiled
 * from the following documents:
 *
 *   IPF Reference 2.00 (updated with APSYMBOL.APS dated 11-17-94)
 *   HTML Markup Language 2.0 (8-4-95)
 *   RTF Specification 1.3 (1-94)
 *
 * The names of the symbols below are mostly, but not always, the same name
 * as the corresponding IPF symbol, HTML entity or RTF control word.  Some
 * were changed for consistency, and some weren't included because they were
 * already listed under a different name.
 *
 * NOTE: symbols are case-sensitive and there are many which differ only
 * by the case of one letter.
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/

#ifndef SYMBOLS_HPP
#define SYMBOLS_HPP

enum Symbol
{
 aa,                // a acute
 Aa,                // A acute
 ac,                // a circumflex
 Ac,                // A circumflex
 acute,             // acute accent
 ae,                // a umlaut
 Ae,                // A umlaut
 aelig,             // ae ligature
 AElig,             // AE ligature
 ag,                // a grave
 Ag,                // A grave
 alpha,             // alpha
 Alpha,             // Alpha
 amp,               // ampersand
 and,               // and
 angstrom,          // angstrom
 ao,                // a overcircle
 Ao,                // A overcircle
 apos,              // apostrophe
 asterisk,          // asterisk
 At,                // A tilde
 at,                // a tilde
 atsign,            // at sign
 aus,               // underscored a
 Beta,              // Beta
 BOX,               // solid box
 box12,             // shaded box 1/2 dots
 box14,             // shaded box 1/4 dots
 box34,             // shaded box 3/4 dots
 BOXBOT,            // solid box bottom half
 BOXLEFT,           // solid box left half
 BOXRIGHT,          // solid box right half
 BOXTOP,            // solid box top half
 bslash,            // back slash
 bullet,            // bullet
 // bx.... are line drawing characters, where .... gives the line thickness
 // at 12, 3, 6 and 9 o'clock positions.  Line thickness may be 0, 1, or 2.
 // thickness of 0 means no line in that direction.
 bx0012,
 bx0021,
 bx0022,
 bx0120,
 bx0121,
 bx0202,
 bx0210,
 bx0212,
 bx0220,
 bx0222,
 bx1002,
 bx1012,
 bx1200,
 bx1201,
 bx1202,
 bx1210,
 bx1212,
 bx2001,
 bx2002,
 bx2020,
 bx2021,
 bx2022,
 bx2100,
 bx2120,
 bx2121,
 bx2200,
 bx2202,
 bx2220,
 bx2222,
 bxas,              // box ascender
 bxcr,              // box cross
 bxde,              // box descender
 bxh,               // box horizontal
 bxle,              // box left junction
 bxll,              // box lower-left
 bxlr,              // box lower-right
 bxri,              // box right junction
 bxul,              // box upper-left
 bxur,              // box upper-right
 bxv,               // box vertical
 caret,             // caret symbol
 cc,                // c cedilla
 Cc,                // C cedilla
 cdq,               // close double quote
 cdqf,              // close French double quote
 cedil,             // cedilla
 cent,              // cent
 colon,             // colon
 comma,             // comma
 copy,              // copyright
 csq,               // close single quote
 curren,            // general currency sign
 darrow,            // down arrow
 dash,              // dash
 degree,            // degree
 delta,             // delta
 divide,            // divide
 dollar,            // dollar sign
 dot,               // dot
 Ea,                // E acute
 ea,                // e acute
 ec,                // e circumflex
 Ec,                // E circumflex
 ee,                // e umlaut
 Ee,                // E umlaut
 eg,                // e grave
 Eg,                // E grave
 emdash,            // em dash
 endash,            // en dash
 epsilon,           // epsilon
 eq,                // equal sign
 ETH,               // Eth, Icelandic
 eth,               // eth, Icelandic
 female,            // female
 fnof,              // function of
 frac12,            // one half
 frac14,            // one fourth
 frac34,            // fraction three-quarters
 Gamma,             // gamma
 ge,                // greater than or equal to
 grave,             // accent grave
 gt,                // greater than
 house,             // house
 hyphen,            // hyphen
 ia,                // i acute
 Ia,                // I acute
 ic,                // i circumflex
 Ic,                // I circumflex
 identical,         // identical to
 ie,                // i umlaut
 Ie,                // I umlaut
 ig,                // i grave
 Ig,                // I grave
 infinity,          // infinity
 intbot,            // integral sign bottom
 intersect,         // set intersection
 inttop,            // integral sign top
 inve,              // inverted exclamation mark
 invq,              // inverted question mark
 lahead,            // left arrowhead
 larrow,            // left arrow
 lbrace,            // left brace
 lbracket,          // left bracket
 le,                // less than or equal to
 lnot,              // logical not
 lnotrev,           // not symbol reversed
 lor,               // logical or
 lpar,              // left parenthesis
 Lsterling,         // pound sterling
 lt,                // less than
 macr,              // macron
 male,              // male
 micro,             // micro prefix
 minus,             // minus sign
 mspace,            // non-breaking space, "m" width
 mu,                // mu
 nearly,            // nearly equal to
 nspace,            // non-breaking space, "n" width
 nt,                // n tilde
 Nt,                // N tilde
 numsign,           // number sign
 oa,                // o acute
 Oa,                // O acute
 oc,                // o circumflex
 Oc,                // O circumflex
 odq,               // open double quote
 odqf,              // open French double quote
 oe,                // o umlaut
 Oe,                // O umlaut
 og,                // o grave
 Og,                // O grave
 Oslash,            // O slash
 oslash,            // o slash
 osq,               // open single quote
 Ot,                // O tilde
 ot,                // o tilde
 ous,               // underscored o
 para,              // paragraph symbol
 per,               // period
 percent,           // percent
 phi,               // lowercase phi
 Phi,               // uppercase Phi
 pi,                // pi
 plus,              // plus sign
 plusmin,           // plusminus
 quot,              // double quote
 rahead,            // right arrowhead
 rarrow,            // right arrow
 rbl,               // required blank (non-breaking)
 rbrace,            // right brace
 rbracket,          // right bracket
 reg,               // registered sign
 rhy,               // required hyphen (non-breaking)
 rpar,              // right parenthesis
 sect,              // section sign
 semi,              // semicolon
 shy,               // soft hyphen
 sigma,             // lowercase sigma
 Sigma,             // uppercase Sigma
 similar,           // similar to
 slash,             // slash
 splitvbar,         // split vertical bar (piping symbol)
 sqbul,             // square bullet
 sqrt,              // square root
 sup1,              // superscript 1
 sup2,              // superscript 2
 sup3,              // superscript 3
 supn,              // superscript n
 szlig,             // sharp s, German sz ligature
 tau,               // tau
 Theta,             // Theta
 THORN,             // THORN, Icelandic
 thorn,             // thorn, Icelandic
 tilde,             // tilde
 times,             // multiplication sign
 ua,                // u acute
 Ua,                // U acute
 uarrow,            // up arrow
 uc,                // u circumflex
 Uc,                // U circumflex
 ue,                // u umlaut
 Ue,                // U umlaut
 ug,                // u grave
 Ug,                // U grave
 uml,               // umlaut
 us,                // underscore
 vbar,              // solid vertical bar
 xclm,              // exclamation point
 Ya,                // Y acute
 yacute,            // y acute
 ye,                // y umlaut
 yen                // Yen
};

#endif

