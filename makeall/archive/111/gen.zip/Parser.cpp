/***************************************************************************
 * File...... Parser.cpp
 * Author.... Mat
 * Date...... 6/16/98
 *
 * Implementation for abstract class Parser
 *
 * Copyright (C) 1998 MekTek
 ***************************************************************************/

#include "Parser.hpp"

Parser::Parser():
  _indicator( 0 )
{}

// default destructor must be declared virtual
Parser::~Parser()
{}


