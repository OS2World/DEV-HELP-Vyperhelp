/***************************************************************************
 * File...... LoadGenerator.cpp
 * Author.... Mat
 * Date...... 5/27/99
 *
 * Implementation for LoadGenerator
 *
 * Copyright (C) 1999 MekTek
 ***************************************************************************/


#include "LoadGenerator.hpp"


LoadGenerator::LoadGenerator():
    Generator( false )
{}


