/***************************************************************************
 * File...... Pen.cpp
 * Author.... Mat
 * Date...... 5/21/96
 *
 * Implementation of Pen
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/

// OpenClass
#include <iexcept.hpp>      // IASSERT macros
#include <itrace.hpp>       // ITRACE macros
#include <ifont.hpp>        // IFont

// TextEditor
#include "LineView.hpp"
#include "FlowView.hpp"
#include "OrderedViewCursor.hpp"
#include "FontInfo.hpp"
#include "Symbol.hpp"
#include "Page.hpp"
#include "FastContext.hpp"
#include "Pen.hpp"


Pen::Pen( Page & page ):
  _page( page )
{}


// null destructor (must be declared virtual)
Pen::~Pen()
{}


void Pen::start( PlacedView & view )
{
  // get line
  LineView * line = (LineView *) view.parent();
  IASSERTSTATE( line );
  IASSERTSTATE( line->isLine() );

  // get line position
  _lineHeight = line->height();
  _lineDescent = line->descent();
  _lineWidth = line->width();
  Coord x = view.isFormatted()? view.position().x(): 0;
  Coord y = _page.size().height() - line->above() - _lineHeight - _lineDescent;
  _point.set( IPair( x, y ) );

  // reset page context to default font
  resetContextFont();

  // get saved state from view, if it has one
  if ( view.isFormatted() )
    setState( view.state() );
}


void Pen::loadFontMetrics( const FontInfo & font )
{
#ifdef IC_TRACE_ALL
  // dump metrics
  font.dumpMetrics( _page.context() );
#endif

  // load font information
  IFont * ifont = font.newFont( _page.context() );
  _maxAscender = ifont->maxAscender();
  _maxDescender = ifont->maxDescender();
  for (int c = 0; c <= UCHAR_MAX; c++)
    _charWidths[c] = ifont->charWidth( c );
  delete ifont;
}


void Pen::forward( Coord width )
{
  // advance the pen point
  _point += IPoint( width, 0 );
}


Boolean Pen::setFont( const IString & name, unsigned long pointSize, Boolean isVector )
{
  if ( ( name != _state.font.name() )
    || ( pointSize != _state.font.pointSize() ) )
  {
    _state.font.setFont( name, pointSize, isVector );
    resetContextFont();
    return true;
  }
  return false;
}


Boolean Pen::setBold( Boolean isBold )
{
  if ( isBold != _state.font.isBold() )
  {
    _state.font.setBold( isBold );
    resetContextFont();
    return true;
  }
  return false;
}


Boolean Pen::setItalic( Boolean isItalic )
{
  if ( isItalic != _state.font.isItalic() )
  {
    _state.font.setItalic( isItalic );
    resetContextFont();
    return true;
  }
  return false;
}


Boolean Pen::setUnderline( Boolean isUnderline )
{
  if ( isUnderline != _state.font.isUnderline() )
  {
    _state.font.setUnderline( isUnderline );
    resetContextFont();
    return true;
  }
  return false;
}


void Pen::resetContextFont()
{
  loadFontMetrics( _state.font );
  IFont * ifont = _state.font.newFont( _page.context() );
  Symbol::setContextFont( _page.context(), *ifont );
  delete ifont;
}


// set internal _state to match given state
void Pen::setState( const PenState & state )
{
  // font attributes
  setFont( state.font.name(), state.font.pointSize(), state.font.isVector() );
  setBold( state.font.isBold() );
  setItalic( state.font.isItalic() );
  setUnderline( state.font.isUnderline() );
}


