/***************************************************************************
 * File...... FlowItem.hpp
 * Author.... Mat
 * Date...... 2/1/96
 *
 * Flow is the basic "meta-item" which handles a sequence of other items
 * and flows them into a specified area.  Flow is used as the top-level
 * Item for the editor.
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/
#ifndef FLOWITEM_HPP
#define FLOWITEM_HPP


// TextEditor
#include "vtext.h"
#include "FlowView.hpp"
#include "OrderedItemCursor.hpp"
#include "Item.hpp"
class View;
class FlowView;
class SmartText;


class FlowItem: public Item
{
  public:
    // constructor
    FlowItem( Item * parent );

    // manipulator
    void insertItem( Item * newItem, Item * itemAfter );

    // from Item
    virtual OrderedItemCursor * newCursor();
    virtual FlowView *          newView( View * parent );
    virtual void                removeChild( Item * item );
    virtual IString             dumpString() const;

  private:
    Item *       _parent;  // NULL if top item
    ItemSequence _children;
};


#endif
