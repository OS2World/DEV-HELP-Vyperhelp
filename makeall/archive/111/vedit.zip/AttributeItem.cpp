/***************************************************************************
 * File...... AttributeItem.cpp
 * Author.... Mat
 * Date...... 4/17/97
 *
 * Implementation of AttributeItem
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// TextEditor
#include "AttributeItem.hpp"
#include "AttributeView.hpp"


AttributeItem::AttributeItem( Item * parent, Type type, Boolean isEnabled ):
    Item( parent ),
    _type( type ),
    _isEnabled( isEnabled )
{}


AttributeItem::Type AttributeItem::type() const
{
  return _type;
}

Boolean AttributeItem::isEnabled() const
{
  return _isEnabled;
}


View * AttributeItem::newView( View * parent )
{
  return new AttributeView( this, parent );
}


IString AttributeItem::asString() const
{
  return IString( "AttributeItem " ) + IString(_type) + IString(_isEnabled);
}

