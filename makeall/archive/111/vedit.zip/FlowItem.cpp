/***************************************************************************
 * File...... FlowItem.cpp
 * Author.... Mat
 * Date...... 2/1/96
 *
 * Implements FlowItem.
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/

// OpenClass
#include <iexcept.hpp>      // IASSERT macros

// TextEditor
#include "SmartText.hpp"
#include "EndItem.hpp"
#include "WordItem.hpp"
#include "SpaceItem.hpp"
#include "FlowItem.hpp"


FlowItem::FlowItem( Item * parent ):
    _parent( parent ),
    _children( 50 )
{
  // initialize empty item list
  _children.add( new EndItem( this ) );
}


OrderedItemCursor * FlowItem::newCursor()
{
  return new OrderedItemCursor( _children );
}


FlowView * FlowItem::newView( View * parent )
{
  /// ignore parent for now -- assume top level
  return new FlowView( this );
}


void FlowItem::removeChild( Item * item )
{
  _children.remove( item );
}


/***************************************************************************
 * Procedure.. FlowItem::insertItem
 * Author..... Mat
 *
 * Insert the new item in front of the cursored item.  Check to see if it is
 * possible to append to the previous WordItem first.
 * Assumes there is always an EndItem which won't allow insertion after.
 *
 ***************************************************************************/
void FlowItem::insertItem( Item * newItem, Item * itemAfter )
{
  // look for the itemAfter
  OrderedItemCursor c( _children );
  Boolean found = _children.locate( itemAfter, *c.cursor() );
  if ( ! found )
    return;

  // special processing for WordItems
  if ( newItem->isWord() )
  {
    // check if a WordItem needs to be merged with one before it
    //   don't attempt to append to the itemAfter
    //   assume that itemAfter already handled that possibility
    OrderedItemCursor cPrevious = c;
    if ( cPrevious.setToPrevious() )
    {
      // check if the preious item is a WordItem
      Item * item = cPrevious.item();
      if ( item->isWord() )
      {
        // yes! append the new word to the previous WordItem
        WordItem * word = (WordItem *) item;
        WordItem * newWord = (WordItem *) newItem;
        word->appendWord( newWord->string() );
        // delete the unused WordItem
        delete newItem;
        // nothing more for this case
        return;
      }
    }
  }

  // add the new item and update the cursor
  _children.addAsPrevious( newItem, *c.cursor() );

  // tell everyone
  notifyObservers( insertItemId, IEventData( &c ) );
}


IString FlowItem::dumpString() const
{
  return IString( "FlowItem" );
}

