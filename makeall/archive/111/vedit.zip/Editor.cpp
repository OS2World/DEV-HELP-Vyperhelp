/***************************************************************************
 * File...... Editor.cpp
 * Author.... Mat
 * Date...... 8/17/95
 *
 * Implementation for Editor
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/

// Streams
#include <fstream.h>
#include <strstrea.h>

// OpenClass
#include <iexcept.hpp>      // IASSERT macros
#include <itrace.hpp>       // ITRACE macros
#include <ivport.hpp>       // IViewPort
#include <iclipbrd.hpp>     // IClipboard
#include <istring.hpp>      // IString
#include <ifiledlg.hpp>     // IFileDialog
#include <ifont.hpp>        // IFont
#include <ifontdlg.hpp>     // IFontDialog
#include <igbitmap.hpp>     // IGBitmap

// Performance Analyzer
#include <icsperf.h>

// Editor
#include "FlowFormatter.hpp"
#include "Page.hpp"
#include "DrawPen.hpp"
#include "FlowItem.hpp"
#include "FlowView.hpp"
#include "LineView.hpp"
#include "FontItem.hpp"
#include "SymbolItem.hpp"
#include "ViewCursor.hpp"
#include "SmartText.hpp"
#include "BoldItem.hpp"
#include "ItalicItem.hpp"
#include "UnderlineItem.hpp"
#include "PushItem.hpp"
#include "PopItem.hpp"
#include "VPort.hpp"
#include "EditorTrigger.hpp"
#include "Editor.hpp"

// Application
#include "vtext.h"


//
// Constructor and Destructor ---------------------------------------
//

Editor::Editor( unsigned long windowId, VPort * viewport, FlowItem * flow )
  : ICanvas( windowId, viewport, viewport ),
    _viewport( viewport ),
    _flowItem( flow ),
    _kursor( this ),
    _isOvertype( false ),
    _isDragActive( false ),
    _current( *this, true ),
    _anchor( *this, true ),
    _anchorOrder( 0 ),
    _formatView( 0 ),
    _beginChange( *this ),
    _endChange( *this ),
    _holdFormatting( 0 ),
    _isSelectionEnabled( true ),
    _trigger( new EditorTrigger( *this ) )
{
  // set background color
  setBackgroundColor( IColor( IColor::white ) );

  // setup handlers
  IPaintHandler::handleEventsFor( this );
  IKeyboardHandler::handleEventsFor( this );
  IMouseHandler::handleEventsFor( this );
  enableNotification();

  // create a FlowView
  _flow = flow->newView( NULL );
  _flow->setEditor( this );

  // create a cursor and start at first View in the flow
  // get the first line
  OrderedViewCursor * lineCursor = _flow->newCursor();
  IBoolean found;
  found = lineCursor->setToFirst();
  IASSERTSTATE( found );

  // now get the first leaf view from the line
  // assume that it's safe to keep the newCursor beyond life of lineCursor!
  _current.set( lineCursor->view()->newCursor() );
  found = _current.cursor()->setToFirst();
  IASSERTSTATE( found );
  delete lineCursor;
}


Editor::~Editor()
{
  delete _flow;
  disableNotification();
  IMouseHandler::stopHandlingEventsFor( this );
  IKeyboardHandler::stopHandlingEventsFor( this );
  IPaintHandler::stopHandlingEventsFor( this );
}


//
// Formatter ---------------------------------------------------------------
//

// format full FlowView
void Editor::resize()
{
  IASSERTSTATE( ! _holdFormatting );
  flushInput();
  format();
}


// format starting at the given line
void Editor::formatStartingAt( PlacedView & startingView )
{
  // if a line is already queued, check which line is earlier
  setFormatView( startingView );

  // if formatting is not on hold, go ahead and format
  if ( ! _holdFormatting )
    checkForFormat();
}


// the given view is compared with the current format view, and if it
// appears earlier, then the format view is updated.  Setting view
// of formatView to NULL indicates first View.  _formatView is 0
// to indicate that no formatting is needed
void Editor::setFormatView( PlacedView & view )
{
  if ( ! _formatView || _flow->orderViews( *_formatView, view ) > 0 )
    _formatView = &view;
}


void Editor::checkForFormat()
{
  // release formatting hold (if it is currently held)
  if ( _holdFormatting )
  {
    // decrement count, don't format if count is still > 0
    if ( --_holdFormatting )
      return;
  }

  // if any request has been queued, then do it!
  if ( _formatView )
    format( _formatView );
  // otherwise if selection has changed, redraw
  else if ( _beginChange.isSet() )
  {
    // pass an empty rect to redraw() to force selected area update
    IRectangle rect;
    redraw( rect );
  }
}


// format the flow using a starting view (if NULL format entire flow)
// keep cursor integrity by avoiding transient views during format
// resize view window (if necessary) and repaint the invalid area
void Editor::format( PlacedView * startingView )
{
  // skip transient views
  _current.skip();
  _anchor.skip();
  _beginChange.skip();
  _endChange.skip();

  // do the formatting
  FlowFormatter formatter( *_flow, _page );
  IRectangle repaintZone = formatter.format( startingView, _viewport->visibleWidth() );

  // return to the skipped transient view, if possible
  _current.unskip();
  _anchor.unskip();
  _beginChange.unskip();
  _endChange.unskip();

  // clear cached format
  _formatView = 0;

  // size to match the FlowView
  ISize newSize( _flow->width(), _flow->extent() );
  if ( newSize != size() )
  {
    sizeTo( newSize );
    _viewport->setViewWindowSize( newSize );
  }

  // repaint the "zone"
  redraw( repaintZone );
}


// forces a refresh of the indicated area
void Editor::redraw( IRectangle & rect )
{
  ITRACE_ALL( IString("Redraw ") + rect.asString() );

  // update selected region
  showSelection( rect );

  // refresh the screen
  refresh( rect );

  // position the keyboard cursor
  positionKursor( true );
}


/***************************************************************************
 * Procedure.. Editor::showSelection
 * Author..... Mat
 * Date....... 8/28/97
 *
 * 1. set the pages selection region.
 * 2. update the refresh area if a selection change has occurred.
 ***************************************************************************/
void Editor::showSelection( IRectangle & rect )
{
  // set page's selection region
  _page.clearSelection();
  if ( _anchorOrder != 0 )
  {
    IASSERTSTATE( _anchor.isSet() );
    View * view1 = ( _anchorOrder > 0 )? _current.leaf(): _anchor.leaf();
    View * view2 = ( _anchorOrder > 0 )? _anchor.leaf(): _current.leaf();
    IASSERTSTATE( view1 && view2 );
    IRectangle rect1 = view1->fullRect();
    IRectangle rect2 = view2->fullRect();

    // add rectangles to the selected region
    // NOTE: exclude x and y extremes (outside border) from rectangle
    if ( rect1.minY() == rect2.minY() )
    {
      // same line
      _page.addToSelection( IRectangle( rect1.minX(), rect1.minY(), rect2.minX()-1, rect2.maxY()-1 ) );
    }
    else
    {
      // multiple lines (extend to edge of page)
      _page.addToSelection( IRectangle( rect1.minX(), rect1.minY(), _flow->width()-1, rect1.maxY()-1 ) );
      if ( rect1.minY() > rect2.maxY() )
        _page.addToSelection( IRectangle( 0, rect2.maxY(), _flow->width()-1, rect1.minY()-1 ) );
      if ( rect2.minX() > 0 )
        _page.addToSelection( IRectangle( 0, rect2.minY(), rect2.minX()-1, rect2.maxY()-1 ) );
    }
  }

  // update redraw rectangle with changed area if applicable
  if ( _beginChange.isSet() )
  {
    // get begin and end view
    IASSERTSTATE( _endChange.isSet() );
    View * view1 = _beginChange.leaf();
    View * view2 = _endChange.leaf();
    IASSERTSTATE( view1 && view2 );

    // get rectangle for begin and end view
    IRectangle rect1 = view1->fullRect();
    IRectangle rect2 = view2->fullRect();
    IRectangle changeRect;
    if ( rect1.minY() == rect2.minY() )
    {
      // same line
      changeRect = IRectangle( rect1.minXMinY(), rect2.minXMaxY() );
    }
    else
    {
      // multiple lines (extend to edge of page)
      changeRect = IRectangle( 0, rect2.minY(), _flow->width(), rect1.maxY() );
    }
    if ( rect.area() )
      rect |= changeRect;
    else
      rect = changeRect;
    ITRACE_ALL( IString("Redraw selection ") + rect.asString() );

    // remove begin/end markers
    resetSelection();
  }
}



//
// Paint Handler -----------------------------------------------------------
//

/***************************************************************************
 * Procedure.. Editor::paintWindow()
 *
 * Called as part of IPaintHandler responsibilities.  Copies invalid region
 * from the memory bitmap which was drawn during formatting.
 ***************************************************************************/
Boolean Editor::paintWindow( IPaintEvent &event )
{
  // determine if part of region needs to be drawn
  IRectangle zone = event.rect() & _viewport->viewWindowDrawRectangle();
  _page.sizeToInvalid( zone );
  if ( zone.area() )
  {
    // draw the zone and validate
    DrawPen pen( _page );
    _flow->draw( pen, zone );
    _page.validate( zone );
  }

  // hide the keyboard cursor
  _kursor.show( false );

  // paint the region
  _page.paint( event );

  // restore the keyboard cursor
  _kursor.show( true );

  return 1;
}




//
// Keyboard Handler --------------------------------------------------------
//

/***************************************************************************
 * Procedure.. Editor::virtualKeyPress()
 *
 * Handle non-text keystrokes.  This is only called on key-down transitions.
 ***************************************************************************/
Boolean Editor::virtualKeyPress( IKeyboardEvent &event )
{
  IKeyboardEvent::VirtualKey virtualKey = event.virtualKey();
  switch ( virtualKey ) {
  case IKeyboardEvent::space:
    {
      insertText( " ", true );
      return true;
    }
  case IKeyboardEvent::enter:
  case IKeyboardEvent::newLine:
    {
      insertText( "\r", true );
      return true;
      // to workaround compiler bug, moved Shift+Enter handling to key()
    }
  case IKeyboardEvent::insert:
    {
      if ( event.isShiftDown() )
      {
        // Shift+Ins = Paste
        paste();
      }
      else
      {
        // Ins = toggle insert mode
        _isOvertype = ! _isOvertype;
        _kursor.setType( _isOvertype? Kursor::overtype: Kursor::insert ).update();
      }
      return true;
    }
  case IKeyboardEvent::deleteKey:
  case IKeyboardEvent::backSpace:
    {
      _holdFormatting++;
      flushInput();
      if ( _anchorOrder == 0 )
        autoSelect( virtualKey == IKeyboardEvent::deleteKey );
      if ( _anchor.isSet() )
        removeSelection();
      checkForFormat();
      return true;
    }
  case IKeyboardEvent::up:
  case IKeyboardEvent::down:
    {
      _holdFormatting++;
      flushInput();
      dropAnchor( event.isShiftDown() );
      moveKursorUpDown( virtualKey == IKeyboardEvent::up );
      checkForFormat();
      return true;
    }
  case IKeyboardEvent::right:
  case IKeyboardEvent::left:
    {
      _holdFormatting++;
      flushInput();
      dropAnchor( event.isShiftDown() );
      moveKursorRightLeft( virtualKey == IKeyboardEvent::right, event.isCtrlDown() );
      checkForFormat();
      return true;
    }
  case IKeyboardEvent::home:
  case IKeyboardEvent::end:
    {
      _holdFormatting++;
      flushInput();
      dropAnchor( event.isShiftDown() );
      if ( event.isCtrlDown() )
        moveKursorTopBottom( virtualKey == IKeyboardEvent::home );
      else
        moveKursorHomeEnd( virtualKey == IKeyboardEvent::home );
      checkForFormat();
      return true;
    }
  case IKeyboardEvent::f8:
    {
      importFile();
      return true;
    }

  case IKeyboardEvent::esc:
    {
      flushInput();
      dump( 9 );
      return true;
    }
  case IKeyboardEvent::f2:
    {
      createGroup( new BoldItem( _flowItem, ! event.isShiftDown() ) );
      return true;
    }
  case IKeyboardEvent::f3:
    {
      createGroup( new ItalicItem( _flowItem, ! event.isShiftDown() ) );
      return true;
    }
  case IKeyboardEvent::f4:
    {
      createGroup( new UnderlineItem( _flowItem, ! event.isShiftDown() ) );
      return true;
    }
  case IKeyboardEvent::f5:
    {
      resize();
      return true;
    }
  case IKeyboardEvent::f7:
    {
      if ( event.isCtrlDown() )
      {
        // display all fonts!
        _holdFormatting++;
        IFont::FaceNameCursor faces( IFont::FaceNameCursor::both, presSpace() );
        IFont font( presSpace() );
        unsigned long size = 18;
        forCursor( faces )
        {
          font.setPointSize( size );
          font.setName( font.faceNameAt( faces ) );
          flushInput();
          insertItem( new FontItem( _flowItem, FontInfo( font ) ) );
          insertText( font.name() + IString("\n") );
          size = 48 - size;
        }
        checkForFormat();
        return true;
      }
      // get an IFont to insert
      IFont font( this );
      IFontDialog::Settings settings( &font );
      IFontDialog dialog( NULL, this, settings );
      if ( dialog.pressedOK() )
        createGroup( new FontItem( _flowItem, FontInfo( font ) ) );
      return true;
    }
  case IKeyboardEvent::f9:
    {
      // insert an empty group
      createGroup( NULL );
      return true;
    }
  case IKeyboardEvent::f6:
    {
      if ( event.isCtrlDown() )
      {
        // display all symbols!
        _holdFormatting++;
        insertText( "\nSymbols by ID:" );
        for (
          Symbol::Identifier id = Symbol::startOfList;
          id <= Symbol::endOfList;
          id = Symbol::Identifier(id+1) )
        {
          insertText( IString(" ") + IString(id) + IString("=") );
          flushInput();
          insertItem( new SymbolItem( Symbol( id ), _flowItem ) );
        }
        insertText( "\nSymbols by char:" );
        for ( int i = 0; i < 256; i++ )
        {
          insertText( IString(" ") + IString(i) + IString("=") );
          flushInput();
          insertItem( new SymbolItem( Symbol( (unsigned char)i ), _flowItem ) );
        }
        checkForFormat();
        return true;
      }
      break;
    }
  } /* endswitch */

  return false;
}

// workaround for OpenClass bug, defect #21395/talcm
// virtualKeyPress is not called for Shift+Enter combination
Boolean Editor::key(IKeyboardEvent& event)
{
    if (event.isUpTransition())
      if (event.isVirtual() && event.isShiftDown())
         if (event.virtualKey() == IKeyboardEvent::enter ||
              event.virtualKey() == IKeyboardEvent::newLine)
         {
           insertText( "\n", true );
           return true;
         }
    return false;
}


/***************************************************************************
 * Procedure.. Editor::characterKeyPress()
 *
 * Handle text keystrokes.  This is only called for key-down transitions.
 ***************************************************************************/
Boolean Editor::characterKeyPress( IKeyboardEvent &event )
{
  insertText( event.mixedCharacter(), true );
  return true;
}


//
// Mouse Handler ----------------------------------------------------
//

/***************************************************************************
 * Procedure.. Editor::mouseClicked()
 *
 * Handle a mouse click.  Invoke newCorrelateCursor() recursively to find the
 * item view nearest to the click point.
 ***************************************************************************/
Boolean Editor::mouseClicked( IMouseClickEvent &event )
{
  // only handle button 1 clicks
  if ( event.mouseButton() != IMouseClickEvent::button1 )
    return false;

  switch ( event.mouseAction() )
  {
    case IMouseClickEvent::click:
      handleMouseMove( event, event.isShiftKeyDown() );
      _isDragActive = false;
      return false;
    case IMouseClickEvent::doubleClick:
      handleDoubleClick();
      _isDragActive = false;
      return false;
    case IMouseClickEvent::down:
      handleMouseMove( event, event.isShiftKeyDown() );
      _isDragActive = true;
      return false;
    case IMouseClickEvent::up:
      handleMouseMove( event, true );
      _isDragActive = false;
      return false;
  }

  /// store the relative y position, too?

  return false;
}


Boolean Editor::mouseMoved( IMouseEvent & event )
{
  if ( _isDragActive )
    handleMouseMove( event, true );

  // return false for default handling
  return false;
}


void Editor::handleMouseMove( IMouseEvent & event, Boolean wantAnchor )
{
  IPoint position = event.mousePosition();

  if ( position != _mousePoint )
  {
    // mouse has moved
    _holdFormatting++;
    flushInput();
    dropAnchor( wantAnchor );
    _kursorPoint = _mousePoint = position;
    adjustKursor();
    checkForFormat();
  }
}


void Editor::handleDoubleClick()
{
  // extend selection to include word
  if ( _current.isWord() )
  {
    _holdFormatting++;
    ViewCursor * wordCursor;
    Boolean ok;

    // select only this word if no current selection, or if anchor in same word
    if ( ! _anchor.isSet() || _current.placed() == _anchor.placed() )
    {
      // set current to beginning of word
      wordCursor = _current.placed()->newCursor();
      IASSERTSTATE( wordCursor );
      ok = wordCursor->setToFirst();
      IASSERTSTATE( ok );
      _current.set( wordCursor );
      // set anchor to end of word
      wordCursor = _current.placed()->newCursor();
      IASSERTSTATE( wordCursor );
      ok = wordCursor->setToLast();
      IASSERTSTATE( ok );
      _anchor.set( wordCursor );
      // advance to next leaf after the word
      ok = _anchor.move( true );
      IASSERTSTATE( ok );
      // refresh entire word
      changeSelection( *_anchor.cursor(), *_current.cursor() );
    }

    // otherwise, extend selection through this word
    else
    {
      // go to start or end or word, whichever extends selection
      wordCursor = _current.placed()->newCursor();
      IASSERTSTATE( wordCursor );
      if ( _anchorOrder < 0 )
        ok = wordCursor->setToLast();
      else
        ok = wordCursor->setToFirst();
      IASSERTSTATE( ok );
      _current.set( wordCursor );
      // advance to next leaf after the word
      if ( _anchorOrder < 0 )
      {
        ok = _current.move( true );
        IASSERTSTATE( ok );
      }
    }

    checkForFormat();
    positionKursor( true );
  }
}


/***************************************************************************
 * Procedure.. Editor::mousePointerChange()
 *
 * Sets the mouse pointer to the text insertion bar while over this window.
 ***************************************************************************/
Boolean Editor::mousePointerChange( IMousePointerEvent & event )
{
  event.setMousePointer( ISystemPointerHandle( ISystemPointerHandle::text ) );
  return true;
}



//
// Kursor Movement --------------------------------------------------
//


/***************************************************************************
 * Procedure.. Editor::moveKursorTopBottom
 * Author..... Mat
 * Date....... 9/3/96
 *
 * Respond to the Ctrl+Home/End keys by moving the kursor to the very top
 * or bottom of the flow (i.e. the very first or very last leaf view)
 ***************************************************************************/
void Editor::moveKursorTopBottom( Boolean moveTop )
{
  // replace current cursor with first/last leaf
  _current.set( _flow->newLeafCursor( moveTop ) );

  // reposition the kursor
  positionKursor( true );
}


/***************************************************************************
 * Procedure.. Editor::moveKursorHomeEnd
 * Author..... Mat
 * Date....... 9/3/96
 *
 * Respond to the Home/End keys by moving the kursor to the "home" or "end"
 * position on the line.
 ***************************************************************************/
void Editor::moveKursorHomeEnd( Boolean moveHome )
{
  // get cursor to current line
  ViewCursor * lineCursor = _current.leaf()->newLineCursor();
  IASSERTSTATE( lineCursor );

  // replace current cursor with first/last leaf from current line
  _current.set( lineCursor->view()->newLeafCursor( moveHome ) );
  delete lineCursor;

  // reposition the kursor
  positionKursor( true );
}


/***************************************************************************
 * Procedure.. Editor::moveKursorUpDown
 * Author..... Mat
 * Date....... 8/13/96
 *
 * Respond to up/down keys.  Move kursor to line above/below if possible
 ***************************************************************************/
void Editor::moveKursorUpDown( Boolean moveUp )
{
  ViewCursor * lineCursor = _current.leaf()->newLineCursor();

  // move to next/previous line
  if ( moveUp )
    lineCursor->setToPrevious();
  else
    lineCursor->setToNext();

  // if move was successful, correlate and reposition view
  if ( lineCursor->isValid() )
  {
    // keep x-value unchanged
    _kursorPoint.setY( lineCursor->view()->position().y() );
    adjustKursor();
  }

  delete lineCursor;
}


/***************************************************************************
 * Procedure.. Editor::moveKursorRightLeft
 * Author..... Mat
 * Date....... 8/13/96
 *
 * Respond to right/left arrow keys.  Move kursor to next/previous leaf view
 * if possible.  Move by word if specified.
 ***************************************************************************/
void Editor::moveKursorRightLeft( Boolean moveRight, Boolean moveByWord )
{
  EditorCursor leafCursor( *this );
  leafCursor = _current;
  Boolean ok = leafCursor.move( moveRight );
  if ( ! ok )
    return;

  // extend the movement through the word
  if ( moveByWord )
  {
    // determine initial state (depending on direction)
    enum { findSpace, findWord, done } state;
    if ( moveRight )
    {
      // if started on a word, then find space first
      state = _current.isWord()? findSpace: findWord;
    }
    else
      state = findWord;

    // search for the next word
    EditorCursor nextLeafCursor( *this );
    do
    {
      Boolean inWord = leafCursor.isWord();
      if ( ( state == findWord && ! inWord ) || ( state == findSpace && inWord ) )
      {
        // keep looking!
        nextLeafCursor = leafCursor;
        ok = nextLeafCursor.move( moveRight );
        if ( ok )
          leafCursor = nextLeafCursor;
        else
          state = done;  // no more Views!
      }
      else if ( state == findSpace )
      {
        state = findWord;  // start looking for a word now
      }
      else
      {
        // looking for a word and found one!
        state = done;
        // if moving left, jump to first character in the word
        if ( ! moveRight )
        {
          ViewCursor * wordCursor = leafCursor.placed()->newCursor();
          IASSERTSTATE( wordCursor );
          Boolean ok = wordCursor->setToFirst();
          IASSERTSTATE( ok );
          leafCursor.set( wordCursor );
        }
      }
    } while ( state < done );
  }

  // replace current cursor with the new leaf cursor
  _current = leafCursor;

  // reposition the kursor
  positionKursor( true );
}


/***************************************************************************
 * Procedure.. Editor::adjustKursor()
 *
 * Clips the current _kursorPoint to be in the visible area, then correlates
 * the clipped point to an item view and updates the _current view.
 ***************************************************************************/
void Editor::adjustKursor()
{
  IRectangle visible = _viewport->viewWindowDrawRectangle();
  IPoint point = _kursorPoint;

  // adjust the point if necessary
  if ( ! visible.contains( point ) ) {
    // adjust x-value
    if ( point.x() > visible.right() ) {
      point.setX( visible.right() );
    } else if ( point.x() < visible.left() ) {
      point.setX( visible.left() );
    } /* endif */
  } /* endif */

  // find the nearest item view & replace the _current cursor
  _current.set( _flow->newCorrelateCursor( point ) );

  // reposition the kursor
  positionKursor( false );
}


/***************************************************************************
 * Procedure.. Editor::positionKursor()
 *
 * Position the kursor to the "current" item/char.
 * The width is set to the current character, the height is set to the
 * current line height.
 *
 * if setKursorPoint = true, then the kursor is reset to
 * the _current leaf view.
 ***************************************************************************/
void Editor::positionKursor( Boolean setKursorPoint )
{
  View * view = _current.leaf();
  IPoint viewPosition = view->fullPosition();

  // set cursor size (height = line height)
  ViewCursor * lineCursor = view->newLineCursor();
  IASSERTSTATE( lineCursor );
  _kursor.sizeTo( ISize( view->width(), lineCursor->view()->extent() ) );
  delete lineCursor;

  // set kursor position
  _kursor.moveTo( viewPosition );

  // update the kursor
  _kursor.update();

  // save the new kursor point
  if ( setKursorPoint )
    _kursorPoint = viewPosition;

  scrollToFit( *_current.cursor() );
}


/***************************************************************************
 * Procedure.. Editor::scrollToFit()
 *
 * Scroll the viewport so that the specified item is fully visible.  If
 * the item is larger then the viewable area, just make sure that it is
 * at least partially visible.
 ***************************************************************************/
void Editor::scrollToFit( ViewCursor & viewCursor )
{
  View * view = viewCursor.view();
  Coord itemWidth = view->width();
  Coord itemLeft = view->fullPosition().x();
  Coord itemRight = itemLeft + itemWidth;

  // scroll the viewport horizintally as necessary
  IRectangle visible = _viewport->viewWindowDrawRectangle();
  if ( itemWidth > visible.width() ) {
    // item is wider than viewport!
    if ( itemRight < visible.minX() || itemLeft > visible.maxX() ) {
      // no portion is visible, fit as much as you can
      _viewport->scrollViewHorizontallyTo( itemLeft );
    } /* endif */
    // otherwise don't scroll -- item is already partially visible
  } else if ( itemLeft < visible.minX() ) {
    // shift view left to fit the character
    _viewport->scrollViewHorizontallyTo( itemLeft );
  } else if ( itemRight > visible.maxX() ) {
    // shift view right to fit the character
    _viewport->scrollViewHorizontallyTo( itemRight - visible.width() );
  } /* endif */

  // scroll the viewport vertically as necessary
  ViewCursor * lineCursor = view->newLineCursor();
  LineView * line = (LineView *) lineCursor->view();
  scrollToFitLine( line );
  delete lineCursor;
}


/***************************************************************************
 * Procedure.. Editor::scrollToFitLine
 *
 * Given a pointer to a LineView in the view hierarchy, scroll the viewport
 * to make sure that the line is fully visible.  If the line is taller than
 * the viewport, make sure at least some of it is visible.
 ***************************************************************************/
void Editor::scrollToFitLine( const LineView * lineView )
{
  Coord lineBottom = lineView->fullPosition().y();
  Coord lineTop = lineBottom + lineView->extent();
  Coord height = size().height();

  // scroll the viewport as necessary
  IRectangle visible = _viewport->viewWindowDrawRectangle();
  if ( lineView->extent() > visible.height() ) {
    // item is taller than viewport!
    if ( lineBottom > visible.maxY() || lineTop < visible.minY() ) {
      // no portion is visible, fit as much as you can
      _viewport->scrollViewVerticallyTo( height - lineBottom - visible.height() );
    } /* endif */
    // otherwise don't scroll -- item is already partially visible
  } else if ( lineBottom < visible.minY() ) {
    // shift view up to fit entire line
    _viewport->scrollViewVerticallyTo( height - lineBottom - visible.height() );
  } else if ( lineTop > visible.maxY() ) {
    // shift view down to fit entire line
    _viewport->scrollViewVerticallyTo( height - lineTop );
  } /* endif */
}


//
// Cursor Support ------------------------------------------------------------
//

/***************************************************************************
 * Procedure.. Editor::dropAnchor
 * Author..... Mat
 * Date....... 11/5/96
 *
 * Drop or lift a selection anchor. (1) If there is no anchor and wantAnchor
 * is set, then an anchor is set at the current position -- it is assumed
 * that the current position will be moved and a leaf anchor will be set at
 * that position, too. (2) if there is an an anchor and wantAnchor is false,
 * then the anchors will be removed.
 *
 * Caller should call checkForFormat to see that format is called if necess.
 ***************************************************************************/
void Editor::dropAnchor( Boolean wantAnchor )
{
  if ( wantAnchor && ! _anchor.isSet() )
  {
    // set the anchor at the current cursor position
    _anchor = _current;
    IASSERTSTATE( _anchor.isSet() );
  }
  else if ( ! wantAnchor && _anchor.isSet() )
  {
    // remove anchors
    // mark change in selection
    changeSelection( *_anchor.cursor(), *_current.cursor() );
    // clear anchor
    _anchorOrder = 0;
    _anchor.clear();
  }
}


void Editor::changeSelection( ViewCursor & cursor1, ViewCursor & cursor2 )
{
  // return if selection is disabled
  if ( ! _isSelectionEnabled || ! _anchor.isSet() )
    return;

  // get first view
  View * view1 = cursor1.view();
  IASSERTSTATE( view1 );

  // get second view
  View * view2 = cursor2.view();
  IASSERTSTATE( view2 );

  // sort the views
  if ( _flow->orderViews( *view1, *view2 ) > 0 )
  {
    View * swap = view1;
    view1 = view2;
    view2 = swap;
  }
  ITRACE_ALL( IString("Select")+view1->dumpString()+IString(" to ")+view2->dumpString() );

  // get begin and end views, or 0 if not defined
  View * begin = _beginChange.leaf();
  View * end = _endChange.leaf();

  // test for new begin or end view
  if ( ! begin || _flow->orderViews( *view1, *begin ) < 0 )
    _beginChange.set( view1->newCursorToThis() );
  if ( ! end || _flow->orderViews( *view2, *end ) > 0 )
    _endChange.set( view2->newCursorToThis() );
}


// set selection-state, based on ordering of the two views
void Editor::refreshSelection()
{
  if ( _anchor.isSet() && _isSelectionEnabled )
    _anchorOrder = _flow->orderViews( *_anchor.leaf(), *_current.leaf() );
}


void Editor::resetSelection()
{
  _beginChange.clear();
  _endChange.clear();
}


// delete existing anchor
// set new anchor adjacent to current cursor
void Editor::autoSelect( Boolean moveRight )
{
  _anchor = _current;
  Boolean ok = _anchor.move( moveRight );
  if ( ! ok )
    _anchorOrder = 0;
  else if ( moveRight )
    _anchorOrder = 1;
  else
    _anchorOrder = -1;
}


//
// Clipboard Operations ---------------------------------------------
//

void Editor::paste()
{
  IClipboard clipboard( this->handle() );

  if ( clipboard.hasText() )
    insertText( clipboard.text() );
}


//
// Item Manipulation ------------------------------------------------
//

void Editor::insertText( const IString & string, Boolean checkOvertype )
{
  // append to the input string
  _input += string;

  if ( checkOvertype && _isOvertype )
  {
    // overtype requires that input be processed now
    if ( _anchorOrder == 0 )
      autoSelect( true );
    flushInput();
  }
  else
  {
    // defer the input so it can be batched if possible
    if ( ! _timer.isStarted() )
      _timer.start( _trigger, 100 );
  }
}


void Editor::flushInput()
{
  _timer.stop();
  if ( _input.length() )
  {
    // hold all formatting
    _holdFormatting++;

    // overwrite selection, if present
    removeSelection();

    // skip transient views
    _current.skip();

    // get the current leaf view and parent for item
    View * leaf = _current.leaf();

    // insert all text items
    SmartText text( _input );
    unsigned n = text.numItems();
    for ( int i = 0; i < n; i++ )
      leaf->insertItem( text.createItem( i, _flowItem ) );

    // check if format is necessary
    checkForFormat();

    // clear the input string
    _input = IString();
  }
}


void Editor::insertItem( Item * item )
{
  // hold all formatting
  _holdFormatting++;
  // overwrite selection, if present
  removeSelection();
  // skip transient views
  _current.skip();
  // insert the item
  _current.leaf()->insertItem( item );
  // check if format is necessary
  checkForFormat();
}


// create a Push-Pop pair around the selected stuff
// if nothing is selected, create an empty Push-Pop pair
// if item is non-NULL, insert it after the Push
void Editor::createGroup( Item * item )
{
  // hold all formatting
  _holdFormatting++;

  // flush any pending text input
  flushInput();

  // get cursor to first and last view
  ViewCursor * cursor1;
  ViewCursor * cursor2;
  _current.skip();
  if ( _anchor.isSet() )
  {
    // there is a selection, use anchor point
    _anchor.skip();
    int order = _flow->orderViews( *_current.leaf(), *_anchor.leaf() );
    if ( order < 0 )
    {
      cursor1 = _current.cursor();
      cursor2 = _anchor.cursor();
    }
    else
    {
      cursor1 = _anchor.cursor();
      cursor2 = _current.cursor();
    }
  }
  else
  {
    // no selection, use current cursor as both first and last
    cursor1 = cursor2 = _current.cursor();
  }

  // get the leaf views
  View * leaf1 = cursor1->view();
  IASSERTSTATE( leaf1 );
  View * leaf2 = cursor2->view();
  IASSERTSTATE( leaf2 );

  // create Push/Pop pair
  PushItem * push = new PushItem( _flowItem );
  PopItem * pop = new PopItem( _flowItem, push );

  // insert the Push/Pop and the item, if provided
  leaf1->insertItem( push );
  if ( item )
    leaf1->insertItem( item );
  leaf2->insertItem( pop );

  // unselect region (otherwise need to extend selection to include new insertions)
  dropAnchor( false );

  // check if format is necessary
  checkForFormat();
}


//
// Commands ---------------------------------------------------------
//

// remove the selected region (as specified by _anchor and _current)
// assume that _formatView == 0 upon entry
// in order to avoid _formatView being set to a deleted view, this
//   procedure will take control of the setting of _formatView such
//   that correct reformatting is done
// views outside of (*after*) the delete region may also be deleted if
//   they are orphaned (e.g., PopViews which have their PushView deleted)
void Editor::removeSelection()
{
  // nothing to do if there is no selection
  if ( ! _anchor.isSet() )
    return;

  // skip transient views
  _current.skip();
  _anchor.skip();

  // nothing to do if _anchor and _current point to same view (order=0)
  if ( ! _anchorOrder )
  {
    _current.unskip();
    dropAnchor( false );
    return;
  }

  // reset selection and formatView in preparation for delete
  resetSelection();
  _isSelectionEnabled = false;
  _formatView = 0;

  // determine order of cursors
  EditorCursor cursor1( *this );
  EditorCursor cursor2( *this );
  if ( _anchorOrder > 0 )
  {
    cursor1 = _current;
    cursor2 = _anchor;
  }
  else
  {
    cursor1 = _anchor;
    cursor2 = _current;
  }

  // move _current back one from the first cursor
  // after deletion is done, _current will be advanced to next valid view
  // _current will not be set if very first view is being deleted
  _current = cursor1;
  _current.move( false );
  Boolean isFormatSet = false;

  // see if in same placed view as cursor1
  // if so, that placed view should be set for formatting
  if ( _current.placed() == cursor1.placed() )
  {
    PlacedView * placed = _current.placed();
    placed->clearFormatted();
    setFormatView( *placed );
    isFormatSet = true;
  }

  // move second cursor back one position
  Boolean ok = cursor2.move( false );
  IASSERTSTATE( ok );

  // clear anchor in case it references a deleted View
  _anchor.clear();
  _anchorOrder = 0;

  // remove the selected area (also deletes cursors)
  _flow->remove( cursor1.give(), cursor2.give() );

  // move _current forward to next valid view
  // this may  not be the same as cursor2, since it may have been orphaned and deleted
  if ( _current.isSet() )
  {
    ok = _current.move( true );
    IASSERTSTATE( ok );
  }
  else
  {
    // move to first leaf cursor
    _current.set( _flow->newLeafCursor( true ) );
  }
  _current.skip();

  // set format view to current if it isn't set yet
  if ( ! isFormatSet )
  {
    PlacedView * placed = _current.placed();
    placed->clearFormatted();
    setFormatView( *placed );
  }

  // check if adjacent words need to be merged
  // need to pass a placedView cursor to checkForWordMerge
  OrderedViewCursor * placedCursor = _flow->newViewCursor( _current.placed() );
  IASSERTSTATE( placedCursor );
  _flow->checkForWordMerge( placedCursor );
  delete placedCursor;

  // re-enable selection
  _isSelectionEnabled = true;
}



//
// File Operations --------------------------------------------------
//

void Editor::importFile()
{
  IFileDialog::Settings fdSettings;
  fdSettings.setOpenDialog();
  IFileDialog fileDlg( NULL, this, fdSettings );
  if ( fileDlg.pressedOK() )
  {
    // open file stream
    ifstream  ifs( fileDlg.fileName() );

    // copy to memory via string stream
    strstream ss;
    ifs >> ss.rdbuf();

    // insert entire file contents as an IString
    const IString string( ss.str() );
    insertText( string );
  }
}


//
// Diagnostic -------------------------------------------------------
//

void Editor::dump( unsigned level )
{
  // dump item tree
  dumpItemNode( _flow->subject(), 0, level );

  // dump view tree
  dumpViewNode( _flow, 0, level );
}

// recursive function to dump Item tree
void Editor::dumpItemNode( Item * item, unsigned indent, unsigned level )
{
  ITRACE_ALL( IString().center( indent )
            + item->dumpString()
            + IString(" [") + IString( (unsigned)item ) + IString("]") );
  if ( ++indent <= level )
  {
    ItemCursor * itemCursor = item->newCursor();
    forCursor( *itemCursor )
    {
      dumpItemNode( itemCursor->item(), indent, level );
    }
    delete itemCursor;
  }
}

// recursive function to dump View tree
void Editor::dumpViewNode( View * view, unsigned indent, unsigned level )
{
  ITRACE_ALL( IString().center( indent )
            + view->dumpString() );
  if ( ++indent <= level )
  {
    ViewCursor * viewCursor = view->newCursor();
    forCursor( *viewCursor )
    {
      dumpViewNode( viewCursor->view(), indent, level );
    }
    delete viewCursor;
  }
}

