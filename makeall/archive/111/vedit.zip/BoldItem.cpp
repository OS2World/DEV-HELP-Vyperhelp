/***************************************************************************
 * File...... BoldItem.cpp
 * Author.... Mat
 * Date...... 4/17/97
 *
 * Implementation of BoldItem
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// TextEditor
#include "BoldItem.hpp"
#include "BoldView.hpp"


BoldItem::BoldItem( Item * parent, Boolean isEnabled ):
    Item( parent ),
    _isEnabled( isEnabled )
{}


View * BoldItem::newView( View * parent )
{
  return new BoldView( this, parent );
}


IString BoldItem::dumpString() const
{
  return IString( "BoldItem " ) + IString(_isEnabled);
}

