/***************************************************************************
 * File...... PenState.hpp
 * Author.... Mat
 * Date...... 10/10/96
 *
 * Holds the state of a Pen, allowing the state to be independently saved
 * and restored as needed.
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/
#ifndef PENSTATE_HPP
#define PENSTATE_HPP


// TextEditor
#include "FontInfo.hpp"


class PenState
{
  public:
    // comparison
    int operator==( const PenState & state ) const;

    // data fields
    FontInfo font;
};


// inline functions
#include "PenState.ipp"


#endif

