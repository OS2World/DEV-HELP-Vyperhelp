/***************************************************************************
 * File...... ParagraphItem.cpp
 * Author.... Mat
 *
 * Implementation of ParagraphItem
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// TextEditor
#include "ParagraphView.hpp"
#include "ParagraphItem.hpp"


ParagraphItem::ParagraphItem( Item * parent ):
    Item( parent )
{}


View * ParagraphItem::newView( View * parent )
{
  return new ParagraphView( this, parent );
}


IString ParagraphItem::dumpString() const
{
  return IString( "ParagraphItem" );
}

