/***************************************************************************
 * File...... SymbolView.cpp
 * Author.... Mat
 * Date...... 4/1/97
 *
 * Implementation of SymbolView.
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// OpenClass
#include <igstring.hpp>     // IGString

// TextEditor
#include "DrawPen.hpp"
#include "FormatPen.hpp"
#include "SymbolView.hpp"
#include "SymbolItem.hpp"

// constant char used to represent symbols that can't map to current code page
static const unsigned char unknownChar = '*';


SymbolView::SymbolView( SymbolItem * subject, View * parent ):
  PlacedView( subject, parent )
{}


PlacedView::FormatChange SymbolView::format( FormatPen & pen )
{
  // do default preparation and formatting
  FormatChange change = PlacedView::format( pen );

  // save old metrics
  Coord oldWidth = _width;
  Coord oldHeight = _height;
  Coord oldDescent = _descent;

  // get new metrics
  _height = pen.maxAscender();
  _descent = pen.maxDescender();
  // map symbol to current code page, if possible
  unsigned char ch = symbol().asChar();
  _width = pen.charWidth( ch? ch: unknownChar );

  // check for size change
  if ( oldWidth != _width
    || oldHeight != _height
    || oldDescent != _descent )
    change = changeSize;

  return change;
}


void SymbolView::draw( DrawPen & pen, const IRectangle & zone )
{
  unsigned char ch = symbol().asChar();
  pen.drawChar( ch? ch: unknownChar );
  pen.forward( _width );

#if 0
  // change color for unknown char
  if (ch == 0 )
  {
    IGraphicBundle bundle;
    bundle.setPenColor( IColor( IColor::paleGray ) );
    gstring.setGraphicBundle( bundle );
  }
#endif
}


const Symbol & SymbolView::symbol() const
{
  SymbolItem * item = (SymbolItem *) subject();
  return item->symbol();
}


IString SymbolView::dumpString() const
{
  return debugString( IString("SymbolView(") + IString(symbol().id()) + IString(")") );
}


