/***************************************************************************
 * File...... PlacedView.cpp
 * Author.... Mat
 * Date...... 1/30/97
 *
 * Implementation for virtual PlacedView base class.
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// TextEditor
#include "FlowItem.hpp"
#include "FormatPen.hpp"
#include "PlacedView.hpp"


PlacedView::PlacedView( Item * subject, View * parent ):
    SubjectView( subject, parent ),
    _xPosition( -1 )
{}


// return size change on first call only
PlacedView::FormatChange PlacedView::format( FormatPen & pen )
{
  // check if formatted yet
  FormatChange change = ( _xPosition == -1 )? changeSize: changeNothing;

  // save the pen's incoming state
  setState( pen.state() );

  // set view position
  Boolean positionChanged = setPosition( pen.point().x() );

  // determine extent of the change
  return positionChanged? changeSize: change;
}


void PlacedView::insertItem( Item * item )
{
  FlowItem * flow = (FlowItem *) subject()->parent();
  flow->insertItem( item, subject() );
}


// most PlacedViews are leafs too, so default returns cursor to this
ViewCursor * PlacedView::newLeafCursor( const Boolean wantFirst )
{
  return newCursorToThis();
}


Boolean PlacedView::setPosition( Coord xPosition )
{
  if ( xPosition != _xPosition )
  {
    _xPosition = xPosition;
    return true;
  }
  return false;
}

