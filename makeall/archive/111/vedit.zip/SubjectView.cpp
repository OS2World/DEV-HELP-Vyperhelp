/***************************************************************************
 * File...... SubjectView.cpp
 * Author.... Mat
 * Date...... 9/9/97
 *
 * Implementation of SubjectView.
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// TextEditor
#include "Item.hpp"
#include "ViewCursor.hpp"
#include "SubjectView.hpp"


SubjectView::SubjectView( Item * subject, View * parent ):
    View( parent ),
    _subject( subject )
{
  if ( _subject )
    _subject->addObserver( *this );
}


unsigned SubjectView::remove( ViewCursor * fromCursor, ViewCursor * toCursor )
{
  // delete cursors if they exist
  delete fromCursor;
  delete toCursor;

  // now delete the subject (this View will get deleted when it gets notiified)
  delete _subject;
  _subject = 0;

  // no view was orphaned
  return 0;
}


void SubjectView::dispatchNotificationEvent( INotificationId id, const IEventData & event )
{
  if ( id == Item::deleteId )
    removeSelf();
}


