/***************************************************************************
 * File...... UnderlineItem.cpp
 * Author.... Mat
 * Date...... 4/17/97
 *
 * Implementation of UnderlineItem
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// TextEditor
#include "UnderlineItem.hpp"
#include "UnderlineView.hpp"


UnderlineItem::UnderlineItem( Item * parent, Boolean isEnabled ):
    Item( parent ),
    _isEnabled( isEnabled )
{}


View * UnderlineItem::newView( View * parent )
{
  return new UnderlineView( this, parent );
}


IString UnderlineItem::dumpString() const
{
  return IString( "UnderlineItem " ) + IString(_isEnabled);
}

