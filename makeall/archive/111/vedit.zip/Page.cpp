/***************************************************************************
 * File...... Page.cpp
 * Author.... Mat
 * Date...... 6/10/97
 *
 * Implements a Page object.
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

//#define DEBUG_DRAW
//#define DEBUG_ZONE

// OpenClass
#include <iwindow.hpp>      // IWindow
#include <irect.hpp>        // IRectangle
#include <igbitmap.hpp>     // IGBitmap
#include <ipainevt.hpp>     // IPaintEvent
#include <itrace.hpp>       // ITRACE macros
#ifdef DEBUG_DRAW
  #include <iframe.hpp>       // IFrameWindow
  #include <icanvas.hpp>      // ICanvas
#endif

// TextEditor
#include "FastContext.hpp"
#include "Page.hpp"


// constructor
Page::Page():
  _context( 0 ),
  _visibleWidth( 0 ),
  _backgroundColor( IColor::white ),
  _hasSelection( false )
{
  // set static defaults (affects all instances!)
  IGraphicContext::setDefaultBackgroundColor( _backgroundColor );
  IGraphicContext::setDefaultBackgroundMixMode( IGraphicBundle::backOverPaint );

  // set attributes for region used for showing selected region
  IGraphicBundle selectionBundle;
  selectionBundle.setMixMode( IGraphicBundle::invert );
  _selectionRegion.setGraphicBundle( selectionBundle );

#ifdef DEBUG_DRAW
  _frame = new IFrameWindow( "Vyper Debugger" );
  _canvas = new ICanvas( IC_FRAME_CLIENT_ID, _frame, _frame ),
  _context = new FastContext( _canvas->handle(), _backgroundColor );
  _frame->setClient( _canvas );
  _canvas->setBackgroundColor( IColor( IColor::paleGray ) );
  _frame->setAutoDestroyWindow( true );
  _canvas->setAutoDestroyWindow( true );
#endif

  // create initial context and set initial transform
  createContext( ISize( 100, 100 ) );
  setTransform( ISize() );
}


Page::~Page()
{
  delete _context;
#ifdef DEBUG_DRAW
  delete _canvas;
  delete _frame;
#endif
}


void Page::createContext( const ISize & contextSize )
{
  // create new context
  FastContext * newContext;
#ifdef DEBUG_DRAW
  _canvas->sizeTo( contextSize );
  _frame->moveSizeToClient( IRectangle( contextSize ) ).show();
  newContext = _context;
#else
  newContext = new FastContext( contextSize, _backgroundColor );
#endif

  // transfer contents of old context to new
  if ( _context )
  {
    // copy page image to upper left of new context
    if ( _size.width() && _size.height() )
    {
      IGBitmap bitmap( *_context, transform( _size ) );
      bitmap.moveTo( IPoint( 0, contextSize.height() - _size.height() ) );
      bitmap.drawOn( *newContext );
    }
#ifndef DEBUG_DRAW
    delete _context;
#endif
  }

  // save new context
  _context = newContext;
  _contextSize = contextSize;
}


void Page::sizeBy( const IPair & offset )
{
  // size the page by the given offset
  ISize nextSize = _size + offset;

  // get a larger context if necessary
  if ( nextSize.height() > _contextSize.height() || nextSize.width() > _contextSize.width() )
  {
    // double the width or height as necessary
    ISize nextContextSize( _contextSize );
    while ( nextSize.height() > nextContextSize.height() )
      nextContextSize.setHeight( nextContextSize.height() * 2 );
    while ( nextSize.width() > nextContextSize.width() )
      nextContextSize.setWidth( nextContextSize.width() * 2 );
    createContext( nextContextSize );
  }

  setTransform( nextSize );
}


void Page::setTransform( const ISize & size )
{
  // if height is changing, shift zone and invalid region by difference
  if ( size.height() != _size.height() )
  {
    IPair diff( 0, size.height() - _size.height() );
    _zone.moveBy( diff );
    _invalidRegion.moveBy( diff );
  }

  // save new size
  _size = size;

  // set transform to place user region in upper left
  ITransformMatrix transform;
  transform.translateBy( IPoint( 0, _contextSize.height() - _size.height() ) );
  _context->setWorldTransformMatrix( transform );
}


IRectangle Page::transform( const IRectangle & rect ) const
{
  return rect.movedBy( IPair( 0, _contextSize.height() - _size.height() ) );
}


void Page::resetSize( Coord visibleWidth )
{
  // reset to 0,0 size (keep context same size)
  _size = ISize();
  _visibleWidth = visibleWidth;
  _zone = IRectangle();
  _invalidRegion.clear();
}


void Page::clearRect( const IRectangle & rect )
{
  // set rectangle size and draw on context
  if ( rect.area() )
  {
    ITRACE_ALL( IString("clearRect ")+rect.asString() );
    _context->clearRect( rect );
    zoneUnion( rect );
  }
}


void Page::shiftRect( const IRectangle & rect, const IPair & offset )
{
  if ( rect.area() && offset != IPair() )
  {
    ITRACE_ALL( IString("shiftRect ")+rect.asString()+IString(" to ")+offset.asString() );
    IRectangle target = rect.movedBy( offset );
    _context->copyRect( rect, target.minXMinY() );
    zoneUnion( target );
  }
}


// IRectangle union operator (|) doesn't support 0-size rectangles
// use area() to check for them and avoid that situation
void Page::zoneUnion( const IRectangle & rect )
{
  if ( rect.area() )
  {
    if ( _zone.area() )
      _zone |= rect;
    else
      _zone = rect;
  }
}


void Page::clearSelection()
{
  _selectionRegion.clear();
  _hasSelection = false;
}


void Page::addToSelection( const IRectangle & rect )
{
  if ( rect.area() )
  {
    _selectionRegion += IGRectangle( rect );
    _hasSelection = true;
  }
}


void Page::paint( IPaintEvent & event )
{
  // get screen context
  IGraphicContext screen( event.presSpaceHandle() );

  // get rectangle to paint
  IRectangle rect = event.rect();

  // if completely outside of page, just flood fill and return
  if ( ! rect.intersects( IRectangle( _size ) ) )
  {
    event.clearBackground( _backgroundColor );
    return;
  }

  // check if wider than page
  if ( rect.maxX() > _size.width() )
  {
    // fill outside area (beyond page width)
    IRectangle outside( _size.width(), rect.minY(), rect.maxX(), rect.maxY() );
    event.clearBackground( outside, _backgroundColor );
    // size paint rectangle down
    rect.sizeTo( IPair( _size.width() - rect.minX(), rect.height() ) );
  }

  // get bitmap of invalid area
  IGBitmap bitmap( *_context, transform( rect ) );

  // copy invalid area from bitmap to screen
  bitmap.moveTo( rect.minXMinY() );
  bitmap.drawOn( screen );

  // invert selected region
  if ( _hasSelection )
    _selectionRegion.drawOn( screen );

#ifdef DEBUG_ZONE
  {
  // draw a frame around zone for debugging (rotate colors)
  static int colorIndex;
  IGRectangle zone( IRectangle( rect.minX(), rect.minY(), rect.maxX()-1, rect.maxY()-1 ) );
  IGraphicBundle bundle;
  bundle.setDrawOperation( IGraphicBundle::frame );
  bundle.setPenColor( IColor( ( colorIndex++ % 15 ) + 1) );
  zone.setGraphicBundle( bundle );
  zone.drawOn( screen );
  }
#endif
}


void Page::sizeToInvalid( IRectangle & rect )
{
  IGRegion unionRegion = _invalidRegion;
  unionRegion &= IGRectangle( rect );
  rect = unionRegion.boundingRect( *_context );
  // check for null region -- there must be a better way!
  if ( rect.minX() < -130000000 )
    rect.sizeTo( IPair() );
}


void Page::invalidate( const IRectangle & rect )
{
  _invalidRegion += IGRectangle( rect );
  // for now, just clear the invalid image
///  clearRect( rect );
}


void Page::validate( const IRectangle & rect )
{
  _invalidRegion -= IGRectangle( rect );
}


