/***************************************************************************
 * File...... VEdit.cpp
 * Author.... Mat
 * Date...... 8/17/95
 *
 * Implementation for VEdit
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/

// Streams
#include <fstream.h>
#include <strstrea.h>

// OpenClass
#include <iexcept.hpp>      // IASSERT macros
#include <itrace.hpp>       // ITRACE macros
#include <ivport.hpp>       // IViewPort
#include <iclipbrd.hpp>     // IClipboard
#include <istring.hpp>      // IString
#include <ifiledlg.hpp>     // IFileDialog
#include <ifont.hpp>        // IFont
#include <ifontdlg.hpp>     // IFontDialog
#include <igbitmap.hpp>     // IGBitmap

// Performance Analyzer
#include <icsperf.h>

// VEdit
#include "FlowFormatter.hpp"
#include "Page.hpp"
#include "FlowItem.hpp"
#include "FlowView.hpp"
#include "LineView.hpp"
#include "LeafView.hpp"
#include "FontItem.hpp"
#include "SymbolItem.hpp"
#include "ViewCursor.hpp"
#include "SmartText.hpp"
#include "ParagraphItem.hpp"
#include "AttributeItem.hpp"
#include "PushItem.hpp"
#include "PopItem.hpp"
#include "VPort.hpp"
#include "VEdit.hpp"

// Application
#include "vtext.h"


//
// Constructor and Destructor ---------------------------------------
//

VEdit::VEdit( unsigned long windowId, VPort * viewport, FlowItem * flow )
  : ICanvas( windowId, viewport, viewport ),
    _viewport( viewport ),
    _flowItem( flow ),
    _kursor( this ),
    _isOvertype( false ),
    _isDragActive( false ),
    _current( NULL ),
    _anchor( NULL ),
    _anchorOrder( 0 ),
    _formatView( NULL ),
    _holdFormatting( false )
{
  // set background color
  /// still need this?
  setBackgroundColor( IColor( IColor::white ) );

  // setup handlers
  IPaintHandler::handleEventsFor( this );
  IKeyboardHandler::handleEventsFor( this );
  IMouseHandler::handleEventsFor( this );
  enableNotification();

  // create a FlowView
  _flow = flow->newView( NULL );
  _flow->setEditor( this );

  // create a cursor and start at first View in the flow
  // get the first line
  OrderedViewCursor * lineCursor = _flow->newCursor();
  IBoolean found;
  found = lineCursor->setToFirst();
  IASSERTSTATE( found );

  // now get the first LeafView from the line
  // assume that it's safe to keep the newCursor beyond life of lineCursor!
  _current = lineCursor->view()->newCursor();
  found = _current->setToFirst();
  IASSERTSTATE( found );
  delete lineCursor;
}


VEdit::~VEdit()
{
  delete _current;
  delete _anchor;
  delete _flow;
  disableNotification();
  IMouseHandler::stopHandlingEventsFor( this );
  IKeyboardHandler::stopHandlingEventsFor( this );
  IPaintHandler::stopHandlingEventsFor( this );
}


//
// Formatter ---------------------------------------------------------------
//

// format full FlowView
VEdit & VEdit::resize()
{
  IASSERTSTATE( ! _holdFormatting );
  return format();
}


// format starting at the given line
VEdit & VEdit::formatStartingAt( View & startingView )
{
  // if a line is already queued, check which line is earlier
  setFormatView( startingView );

  // if formatting is not on hold, go ahead and format
  if ( ! _holdFormatting )
    return checkForFormat( false );

  return *this;
}


// the given view is compared with the current format view, and if it
// appears earlier, then the format view is updated.  Setting view
// of formatView to NULL indicates first View.  _formatView is NULL
// to indicate that no formatting is needed
VEdit & VEdit::setFormatView( View & view )
{
  if ( _formatView == NULL ||
       _flow->orderViews( *_formatView, view ) > 0 )
    _formatView = &view;
  return *this;
}


VEdit & VEdit::checkForFormat( Boolean resetHold )
{
  // release formatting hold
  if ( resetHold )
    _holdFormatting = false;

  // if any request has been queued, then do it!
  if ( _formatView )
    format( _formatView );

  // otherwise just return
  return *this;
}


// format the flow using a starting view (if NULL format entire flow)
// keep cursor integrity by avoiding transient views during format
// resize view window (if necessary) and repaint the invalid area
VEdit & VEdit::format( View * startingView )
{
  // skip transient views
  Boolean isCurrentMoved = skipTransients( false, true );  /// false
  Boolean isAnchorMoved = skipTransients( true, true );  /// false

  // do the formatting
  FlowFormatter formatter( *_flow, _page );
  IRectangle repaintZone = formatter.format( startingView, _viewport->visibleWidth() );

  // return to the skipped transient view, if possible
  if ( isCurrentMoved )
    unskipTransients();
  if ( isAnchorMoved )
    unskipTransients( true );

  // clear cached format
  _formatView = NULL;

  // size to match the FlowView
  ISize newSize( _flow->width(), _flow->extent() );
  if ( newSize != size() )
  {
    sizeTo( newSize );
    _viewport->setViewWindowSize( newSize );
  }

  // repaint the "zone"
  return redraw( repaintZone );
}


// forces a refresh of the indicated area
VEdit & VEdit::redraw( const IRectangle & rect )
{
  ITRACE_ALL( IString("Redraw ") + rect.asString() );

  // refresh the screen
  refresh( rect );

  // position the keyboard cursor
  positionKursor( true );

  return *this;
}



//
// Paint Handler -----------------------------------------------------------
//

/***************************************************************************
 * Procedure.. VEdit::paintWindow()
 *
 * Called as part of IPaintHandler responsibilities.  Copies invalid region
 * from the memory bitmap which was drawn during redraw().
 ***************************************************************************/
Boolean VEdit::paintWindow( IPaintEvent &event )
{
  // hide the keyboard cursor
  _kursor.show( false );

  // paint the region
  _page.paint( event );

  // restore the keyboard cursor
  _kursor.show( true );

  return 1;
}




//
// Keyboard Handler --------------------------------------------------------
//

/***************************************************************************
 * Procedure.. VEdit::virtualKeyPress()
 *
 * Handle non-text keystrokes.  This is only called on key-down transitions.
 ***************************************************************************/
Boolean VEdit::virtualKeyPress( IKeyboardEvent &event )
{
  IKeyboardEvent::VirtualKey virtualKey = event.virtualKey();
  switch ( virtualKey ) {
  case IKeyboardEvent::space:
    {
      insertText( " ", true );
      return true;
    }
  case IKeyboardEvent::enter:
  case IKeyboardEvent::newLine:
    {
      insertItem( new ParagraphItem( _flowItem ) );
      return true;
      // to workaround compiler bug, moved Shift+Enter handling to key()
    }
  case IKeyboardEvent::insert:
    {
      if ( event.isShiftDown() ) {
        // Shift+Ins = Paste
        paste();
      } else {
        // Ins = toggle insert mode
        _isOvertype = ! _isOvertype;
        /// need to keep track of current state & toggle
        _kursor.setType( _isOvertype? Kursor::overtype: Kursor::insert ).update();
      } /* endif */
      return true;
    }
  case IKeyboardEvent::deleteKey:
  case IKeyboardEvent::backSpace:
    {
      if ( _anchor == NULL )
        _anchor = newCursorRightLeft( *_current, virtualKey == IKeyboardEvent::deleteKey );
      if ( _anchor )
      {
        _holdFormatting = true;
        removeSelection();
        checkForFormat();
      }
      return true;
    }
  case IKeyboardEvent::up:
  case IKeyboardEvent::down:
    {
      _holdFormatting = true;
      dropAnchor( event.isShiftDown() );
      moveKursorUpDown( virtualKey == IKeyboardEvent::up );
      checkForFormat();
      return true;
    }
  case IKeyboardEvent::right:
  case IKeyboardEvent::left:
    {
      _holdFormatting = true;
      dropAnchor( event.isShiftDown() );
      moveKursorRightLeft( virtualKey == IKeyboardEvent::right );
      checkForFormat();
      return true;
    }
  case IKeyboardEvent::home:
  case IKeyboardEvent::end:
    {
      _holdFormatting = true;
      dropAnchor( event.isShiftDown() );
      if ( event.isCtrlDown() )
        moveKursorTopBottom( virtualKey == IKeyboardEvent::home );
      else
        moveKursorHomeEnd( virtualKey == IKeyboardEvent::home );
      checkForFormat();
      return true;
    }
  case IKeyboardEvent::f8:
    {
      importFile();
      return true;
    }

  case IKeyboardEvent::esc:
    {
      dump( 9 );
      return true;
    }
  case IKeyboardEvent::f2:
    {
      createGroup( new AttributeItem( _flowItem, AttributeItem::bold, ! event.isShiftDown() ) );
      return true;
    }
  case IKeyboardEvent::f3:
    {
      createGroup( new AttributeItem( _flowItem, AttributeItem::italic, ! event.isShiftDown() ) );
      return true;
    }
  case IKeyboardEvent::f4:
    {
      createGroup( new AttributeItem( _flowItem, AttributeItem::underline, ! event.isShiftDown() ) );
      return true;
    }
  case IKeyboardEvent::f5:
    {
      resize();
      return true;
    }
  case IKeyboardEvent::f7:
    {
      if ( event.isCtrlDown() )
      {
        // display all fonts!
        IFont::FaceNameCursor faces( IFont::FaceNameCursor::both, presSpace() );
        IFont font( presSpace() );
        unsigned long size = 18;
        forCursor( faces )
        {
          font.setPointSize( size );
          font.setName( font.faceNameAt( faces ) );
          insertItem( new FontItem( _flowItem, FontInfo( font ) ) );
          insertText( font.name() + IString("\n") );
          size = 48 - size;
        }
        return true;
      }
      // get an IFont to insert
      IFont font( this );
      IFontDialog::Settings settings( &font );
      IFontDialog dialog( NULL, this, settings );
      if ( dialog.pressedOK() )
        createGroup( new FontItem( _flowItem, FontInfo( font ) ) );
      return true;
    }
  case IKeyboardEvent::f9:
    {
      // insert an empty group
      createGroup( NULL );
      return true;
    }
  case IKeyboardEvent::f6:
    {
      if ( event.isCtrlDown() )
      {
        // display all symbols!
        insertText( "\nSymbols by ID:" );
        for (
          Symbol::Identifier id = Symbol::startOfList;
          id <= Symbol::endOfList;
          id = Symbol::Identifier(id+1) )
        {
          insertText( IString(" ") + IString(id) + IString("=") );
          insertItem( new SymbolItem( Symbol( id ), _flowItem ) );
        }
        insertText( "\nSymbols by char:" );
        for ( int i = 0; i < 256; i++ )
        {
          insertText( IString(" ") + IString(i) + IString("=") );
          insertItem( new SymbolItem( Symbol( (unsigned char)i ), _flowItem ) );
        }
        return true;
      }
      break;
    }
  } /* endswitch */

  return false;
}

// workaround for OpenClass bug, defect #21395/talcm
// virtualKeyPress is not called for Shift+Enter combination
Boolean VEdit::key(IKeyboardEvent& event)
{
    if (event.isUpTransition())
      if (event.isVirtual() && event.isShiftDown())
         if (event.virtualKey() == IKeyboardEvent::enter ||
              event.virtualKey() == IKeyboardEvent::newLine)
         {
           insertText( "\n" );
           return true;
         }
    return false;
}


/***************************************************************************
 * Procedure.. VEdit::characterKeyPress()
 *
 * Handle text keystrokes.  This is only called for key-down transitions.
 ***************************************************************************/
Boolean VEdit::characterKeyPress( IKeyboardEvent &event )
{
  insertText( event.mixedCharacter(), true );
  return true;
}


//
// Mouse Handler ----------------------------------------------------
//

/***************************************************************************
 * Procedure.. VEdit::mouseClicked()
 *
 * Handle a mouse click.  Invoke newCorrelateCursor() recursively to find the
 * item view nearest to the click point.
 ***************************************************************************/
Boolean VEdit::mouseClicked( IMouseClickEvent &event )
{
  // only handle button 1 clicks
  if ( event.mouseButton() != IMouseClickEvent::button1 )
    return false;

  switch ( event.mouseAction() )
  {
    case IMouseClickEvent::click:
      handleMouseMove( event, event.isShiftKeyDown() );
      return false;
    case IMouseClickEvent::down:
      handleMouseMove( event, event.isShiftKeyDown() );
      _isDragActive = true;
      return false;
    case IMouseClickEvent::up:
      handleMouseMove( event, true );
      _isDragActive = false;
      return false;
  }

  /// store the relative y position, too?

  return false;
}


Boolean VEdit::mouseMoved( IMouseEvent & event )
{
  if ( _isDragActive )
    handleMouseMove( event, true );

  // return false for default handling
  return false;
}


VEdit & VEdit::handleMouseMove( IMouseEvent & event, Boolean wantAnchor )
{
  IPoint position = event.mousePosition();

  if ( position != _mousePoint )
  {
    // mouse has moved
    _holdFormatting = true;
    dropAnchor( wantAnchor );
    _kursorPoint = _mousePoint = position;
    adjustKursor();
    checkForFormat();
  }

  return *this;
}


/***************************************************************************
 * Procedure.. VEdit::mousePointerChange()
 *
 * Sets the mouse pointer to the text insertion bar while over this window.
 ***************************************************************************/
Boolean VEdit::mousePointerChange( IMousePointerEvent & event )
{
  event.setMousePointer( ISystemPointerHandle( ISystemPointerHandle::text ) );
  return true;
}



//
// Kursor Movement --------------------------------------------------
//


/***************************************************************************
 * Procedure.. VEdit::moveKursorTopBottom
 * Author..... Mat
 * Date....... 9/3/96
 *
 * Respond to the Ctrl+Home/End keys by moving the kursor to the very top
 * or bottom of the flow (i.e. the very first or very last leaf view)
 ***************************************************************************/
VEdit & VEdit::moveKursorTopBottom( Boolean moveTop )
{
  // replace current cursor with first/last leaf
  setCurrent( _flow->newLeafCursor( moveTop ) );

  // reposition the kursor
  return positionKursor( true );
}


/***************************************************************************
 * Procedure.. VEdit::moveKursorHomeEnd
 * Author..... Mat
 * Date....... 9/3/96
 *
 * Respond to the Home/End keys by moving the kursor to the "home" or "end"
 * position on the line.
 ***************************************************************************/
VEdit & VEdit::moveKursorHomeEnd( Boolean moveHome )
{
  // get cursor to current line
  View * view = _current->view();
  ViewCursor * lineCursor = view->newLineCursor();
  IASSERTSTATE( lineCursor );

  // replace current cursor with first/last leaf from current line
  setCurrent( lineCursor->view()->newLeafCursor( moveHome ) );
  delete lineCursor;

  // reposition the kursor
  return positionKursor( true );
}


/***************************************************************************
 * Procedure.. VEdit::moveKursorUpDown
 * Author..... Mat
 * Date....... 8/13/96
 *
 * Respond to up/down keys.  Move kursor to line above/below if possible
 ***************************************************************************/
VEdit & VEdit::moveKursorUpDown( Boolean moveUp )
{
  View * view = _current->view();
  ViewCursor * lineCursor = view->newLineCursor();

  // move to next/previous line
  if ( moveUp )
    lineCursor->setToPrevious();
  else
    lineCursor->setToNext();

  // if move was successful, correlate and reposition view
  if ( lineCursor->isValid() )
  {
    // keep x-value unchanged
    _kursorPoint.setY( lineCursor->view()->position().y() );
    adjustKursor();
  }

  delete lineCursor;

  return *this;
}


/***************************************************************************
 * Procedure.. VEdit::moveKursorRightLeft
 * Author..... Mat
 * Date....... 8/13/96
 *
 * Respond to right/left arrow keys.  Move kursor to next/previous leaf view
 * if possible.
 ***************************************************************************/
VEdit & VEdit::moveKursorRightLeft( Boolean moveRight )
{
  ViewCursor * leafCursor = newCursorRightLeft( *_current, moveRight );
  if ( leafCursor )
  {
    // replece current cursor with the new leaf cursor
    setCurrent( leafCursor );
    // reposition the kursor
    positionKursor( true );
  }
  return *this;
}

/***************************************************************************
 * Procedure.. VEdit::adjustKursor()
 *
 * Clips the current _kursorPoint to be in the visible area, then correlates
 * the clipped point to an item view and updates the _current view.
 ***************************************************************************/
VEdit & VEdit::adjustKursor()
{
  IRectangle visible = _viewport->viewWindowDrawRectangle();
  IPoint point = _kursorPoint;

  // adjust the point if necessary
  if ( ! visible.contains( point ) ) {
    // adjust x-value
    if ( point.x() > visible.right() ) {
      point.setX( visible.right() );
    } else if ( point.x() < visible.left() ) {
      point.setX( visible.left() );
    } /* endif */
  } /* endif */

  // find the nearest item view & replace the _current cursor
  setCurrent( _flow->newCorrelateCursor( point ) );

  // reposition the kursor
  return positionKursor( false );
}


/***************************************************************************
 * Procedure.. VEdit::positionKursor()
 *
 * Position the kursor to the "current" item/char.
 * The width is set to the current character, the height is set to the
 * current line height.
 *
 * if setKursorPoint = true, then the kursor is reset to the point to the
 * the _current leaf view.
 ***************************************************************************/
VEdit & VEdit::positionKursor( Boolean setKursorPoint )
{
  View * view = _current->view();
  IPoint viewPosition = view->absolutePosition();

  // set cursor size (height = line height)
  ViewCursor * lineCursor = view->newLineCursor();
  IASSERTSTATE( lineCursor );
  _kursor.sizeTo( ISize( view->width(), lineCursor->view()->extent() ) );
  delete lineCursor;

  // set kursor position
  _kursor.moveTo( viewPosition );

  // update the kursor
  _kursor.update();

  // save the new kursor point
  if ( setKursorPoint )
    _kursorPoint = viewPosition;

  return scrollToFit( *_current );
}


/***************************************************************************
 * Procedure.. VEdit::scrollToFit()
 *
 * Scroll the viewport so that the specified item is fully visible.  If
 * the item is larger then the viewable area, just make sure that it is
 * at least partially visible.
 ***************************************************************************/
VEdit & VEdit::scrollToFit( ViewCursor & viewCursor )
{
  View * view = viewCursor.view();
  Coord itemWidth = view->width();
  Coord itemLeft = view->absolutePosition().x();
  Coord itemRight = itemLeft + itemWidth;

  // scroll the viewport horizintally as necessary
  IRectangle visible = _viewport->viewWindowDrawRectangle();
  if ( itemWidth > visible.width() ) {
    // item is wider than viewport!
    if ( itemRight < visible.minX() || itemLeft > visible.maxX() ) {
      // no portion is visible, fit as much as you can
      _viewport->scrollViewHorizontallyTo( itemLeft );
    } /* endif */
    // otherwise don't scroll -- item is already partially visible
  } else if ( itemLeft < visible.minX() ) {
    // shift view left to fit the character
    _viewport->scrollViewHorizontallyTo( itemLeft );
  } else if ( itemRight > visible.maxX() ) {
    // shift view right to fit the character
    _viewport->scrollViewHorizontallyTo( itemRight - visible.width() );
  } /* endif */

  // scroll the viewport vertically as necessary
  ViewCursor * lineCursor = view->newLineCursor();
  LineView * line = (LineView *) lineCursor->view();
  scrollToFitLine( line );
  delete lineCursor;

  return *this;
}


/***************************************************************************
 * Procedure.. VEdit::scrollToFitLine
 *
 * Given a pointer to a LineView in the view hierarchy, scroll the viewport
 * to make sure that the line is fully visible.  If the line is taller than
 * the viewport, make sure at least some of it is visible.
 ***************************************************************************/
VEdit & VEdit::scrollToFitLine( const LineView * lineView )
{
  Coord lineBottom = lineView->absolutePosition().y();
  Coord lineTop = lineBottom + lineView->extent();
  Coord height = size().height();

  // scroll the viewport as necessary
  IRectangle visible = _viewport->viewWindowDrawRectangle();
  if ( lineView->extent() > visible.height() ) {
    // item is taller than viewport!
    if ( lineBottom > visible.maxY() || lineTop < visible.minY() ) {
      // no portion is visible, fit as much as you can
      _viewport->scrollViewVerticallyTo( height - lineBottom - visible.height() );
    } /* endif */
    // otherwise don't scroll -- item is already partially visible
  } else if ( lineBottom < visible.minY() ) {
    // shift view up to fit entire line
    _viewport->scrollViewVerticallyTo( height - lineBottom - visible.height() );
  } else if ( lineTop > visible.maxY() ) {
    // shift view down to fit entire line
    _viewport->scrollViewVerticallyTo( height - lineTop );
  } /* endif */

  return *this;
}


//
// Cursor Support ------------------------------------------------------------
//

/***************************************************************************
 * Procedure.. VEdit::dropAnchor
 * Author..... Mat
 * Date....... 11/5/96
 *
 * Drop or lift a selection anchor. (1) If there is no anchor and wantAnchor
 * is set, then an anchor is set at the current position -- it is assumed
 * that the current position will be moved and a leaf anchor will be set at
 * that position, too. (2) if there is an an anchor and wantAnchor is false,
 * then the anchors will be removed.
 *
 * Caller should call checkForFormat to see that format is called if necess.
 ***************************************************************************/
VEdit & VEdit::dropAnchor( Boolean wantAnchor )
{
  if ( wantAnchor && ! _anchor )
  {
    // set the anchor at the current cursor position
    _anchor = _current->view()->newCursorToThis();
    IASSERTSTATE( _anchor );
  }
  else if ( ! wantAnchor && _anchor )
  {
    // remove anchors from both _current and _anchor
    removeAnchors();
    delete _anchor;
    _anchor = NULL;
  }

  return *this;
}


/***************************************************************************
 * Procedure.. VEdit::setCurrent
 * Author..... Mat
 * Date....... 11/7/96
 *
 * Called to change the current cursor.  Handles changing anchors as
 * necessary.  If cursor = NULL, then just update current selection.
 *
 * Caller should call checkForFormat to see that format is called if necess.
 ***************************************************************************/
VEdit & VEdit::setCurrent( ViewCursor * cursor, Boolean updateSelection )
{
  LeafView * anchorView;
  LeafView * currentView;

  // clear anchor at current location
  if ( _anchor && updateSelection && cursor )
  {
    currentView = (LeafView *) _current->view();
    IASSERTSTATE( currentView );
    setLeafSelection( *currentView, LeafView::noSelection );
  }

  // move to new location
  if ( cursor )
  {
    delete _current;
    _current = cursor;
  }

  // set anchors at new location
  if ( _anchor && updateSelection )
  {
    // get anchor view
    anchorView = (LeafView *) _anchor->view();
    IASSERTSTATE( anchorView );
    // get new current view
    currentView = (LeafView *) _current->view();
    IASSERTSTATE( currentView );
    // set selection-state, based on ordering of the two views
    int order = _flow->orderViews( *anchorView, *currentView );
    if ( order < 0 )
    {
      // anchor comes before current
      order = -1;
      if ( order != _anchorOrder )
      {
        setLeafSelection( *anchorView, LeafView::beginSelection );
        _anchorOrder = order;
      }
      setLeafSelection( *currentView, LeafView::endSelection );
    }
    else if ( order > 0 )
    {
      // current comes before anchor
      order = 1;
      if ( order != _anchorOrder )
      {
        setLeafSelection( *anchorView, LeafView::endSelection );
        _anchorOrder = order;
      }
      setLeafSelection( *currentView, LeafView::beginSelection );
    }
    else
    {
      // current and anchor point to same spot: no selection!
      setLeafSelection( *anchorView, LeafView::noSelection );
      setLeafSelection( *currentView, LeafView::noSelection );
      // assume _anchorOrder has changed
      _anchorOrder = order;
    }
  }

  return *this;
}


// very similar to setCurrent -- could share code
VEdit & VEdit::setAnchor( ViewCursor * cursor, Boolean updateSelection )
{
  LeafView * anchorView;
  LeafView * currentView;

  // clear anchor at anchor location
  IASSERTSTATE( _anchor );
  if ( updateSelection && cursor )
  {
    anchorView = (LeafView *) _anchor->view();
    IASSERTSTATE( anchorView );
    setLeafSelection( *anchorView, LeafView::noSelection );
  }

  // move to new location
  if ( cursor )
  {
    delete _anchor;
    _anchor = cursor;
  }

  // set anchors at new location
  if ( updateSelection )
  {
    // get anchor view
    anchorView = (LeafView *) _anchor->view();
    IASSERTSTATE( anchorView );
    // get new anchor view
    currentView = (LeafView *) _current->view();
    IASSERTSTATE( currentView );
    // set selection-state, based on ordering of the two views
    int order = _flow->orderViews( *anchorView, *currentView );
    if ( order < 0 )
    {
      // anchor comes before current
      order = -1;
      if ( order != _anchorOrder )
      {
        setLeafSelection( *currentView, LeafView::endSelection );
        _anchorOrder = order;
      }
      setLeafSelection( *anchorView, LeafView::beginSelection );
    }
    else if ( order > 0 )
    {
      // current comes before anchor
      order = 1;
      if ( order != _anchorOrder )
      {
        setLeafSelection( *currentView, LeafView::beginSelection );
        _anchorOrder = order;
      }
      setLeafSelection( *anchorView, LeafView::endSelection );
    }
    else
    {
      // anchor and anchor point to same spot: no selection!
      setLeafSelection( *anchorView, LeafView::noSelection );
      setLeafSelection( *currentView, LeafView::noSelection );
      // assume _currentOrder has changed
      _anchorOrder = order;
    }
  }

  return *this;
}


/***************************************************************************
 * VEdit::skipTransients
 *
 * Move the given cursor past any transient views in preparation for a
 * command.  Change or re-allocate the given cursor.  Return true if
 * any skip was necessary.
 *
 * Only works for _current or _anchor.  If useAnchor is true, then
 * _anchor is checked, otherwise _current is checked.
 ***************************************************************************/
Boolean VEdit::skipTransients( Boolean useAnchor, Boolean updateSelection )
{
  View * view;
  ViewCursor * cursor;
  ViewCursor * newCursor;
  Boolean skipped = false;

  // nothing to do if there is no anchor
  if ( useAnchor && _anchor == NULL )
    return false;

  // get initial cursor
  cursor = useAnchor? _anchor: _current;

  // get initial view
  view = cursor->view();
  IASSERTSTATE( view );

  // skip any transient views
  while ( view->isTransient() )
  {
    // get new cursor to the right
    newCursor = newCursorRightLeft( *cursor, true );
    IASSERTSTATE( newCursor );
    skipped = true;

    // assign the new cursor
    if ( useAnchor )
      setAnchor( newCursor, updateSelection );
    else
      setCurrent( newCursor, updateSelection );
    cursor = newCursor;

    // get the view
    view = cursor->view();
    IASSERTSTATE( view );
  }

  // set return value
  return skipped;
}


/***************************************************************************
 * VEdit::unskipTransients
 *
 * Undoes a previous skipTransients() call.  CURRENTLY ASSUMES THE FOLLOWING:
 *   1. Only one skip needs to be undone.
 *   2. If the previous view is transient, then it is the skipped view
 ***************************************************************************/
 VEdit & VEdit::unskipTransients( Boolean useAnchor )
{
  ViewCursor * cursor;
  ViewCursor * newCursor;

  // get initial cursor (skipped ahead)
  cursor = useAnchor? _anchor: _current;
  IASSERTSTATE( cursor );

  newCursor = newCursorRightLeft( *cursor, false );
  if ( newCursor )
  {
    View * view = newCursor->view();
    IASSERTSTATE( view );
    // assume any transient view is the one we skipped
    if ( view->isTransient() )
    {
      // fixup selection state of the leaf we were temporarily moved to
      LeafView * leaf = (LeafView *) cursor->view();
      IASSERTSTATE( leaf );
      if ( leaf->selection() != LeafView::noSelection )
      {
        View * placed = placedFromLeaf( *leaf );
        IASSERTSTATE( placed );
        placed->savedState()->isInverted = ( leaf->selection() == LeafView::beginSelection );
      }
      // return to that view /// (selection should be unchanged from before skip)
      if ( useAnchor )
        setAnchor( newCursor, true );  /// false
      else
        setCurrent( newCursor, true );  /// false
    }
    else
    {
      // previous view isn't a skipped transient
      delete newCursor;
      // update the selection without moving the cursor
#if 0 ///
      if ( useAnchor )
        setAnchor( NULL, true );
      else
        setCurrent( NULL, true );
#endif
    }
  }

  return *this;
}


/***************************************************************************
 * Procedure.. VEdit::newCursorRightLeft
 * Author..... Mat
 * Date....... 3/14/97
 *
 * Given a cursor as a starting point, move right or left to the next cursor,
 * moving to a new line if necessary.  Return the new view cursor, or NULL
 * if the move isn't possible.
 ***************************************************************************/
ViewCursor * VEdit::newCursorRightLeft( ViewCursor & cursor, Boolean moveRight )
{
  ViewCursor * leafCursor = NULL;

  // get a copy of the given cursor
  ViewCursor * viewCursor = cursor.view()->newCursorToThis();
  IASSERTSTATE( viewCursor );

  do
  {
    Boolean noMove = moveRight? viewCursor->isLast(): viewCursor->isFirst();

    // try to move the current cursor
    if ( noMove ) {
      // can't move, move up a level on the tree
      View * parent;
      ViewCursor * parentCursor = NULL;
      parent = viewCursor->view()->parent();
      if ( parent )
        parentCursor = parent->newCursorToThis();

      // free the old cursor
      delete viewCursor;

      // if found a parent go to it, otherwise get out
      if ( parentCursor )
        viewCursor = parentCursor;
      else
        return NULL;
    }
    else
    {
      // move ahead/back and look for a leaf
      if ( moveRight )
        viewCursor->setToNext();
      else
        viewCursor->setToPrevious();
      leafCursor = viewCursor->view()->newLeafCursor( moveRight );
    }

  } while ( leafCursor == NULL );

  /// OK to delete viewCursor before using leafCursor?
  delete viewCursor;

  return leafCursor;
}


//
// Formatting Helpers -----------------------------------------------
//

// given a leaf view, find the placed view which it belongs to
// in many cases the LeafView is itself a placed view (IconView, SpaceView)
// an example where they are not the same is CharView and WordView
// find line, and then direct descendent, to determine if it is earlier
View * VEdit::placedFromLeaf( LeafView & leaf )
{
  ViewCursor * lineCursor = leaf.newLineCursor();
  IASSERTSTATE( lineCursor );
  LineView * line = (LineView *) lineCursor->view();
  View * placedView = line->locateDescendent( leaf );
  IASSERTSTATE( placedView );
  delete lineCursor;
  return placedView;
}


VEdit & VEdit::setLeafSelection( LeafView & leaf, LeafView::Selection selection )
{
  // format is required when anchors change
  View * placedView = placedFromLeaf( leaf );
  setFormatView( *placedView );

  // set the anchor at the leaf
  leaf.setSelection( selection );

  return *this;
}


VEdit & VEdit::removeAnchors()
{
  // remove an existing anchor
  LeafView * leaf = (LeafView *) _anchor->view();
  IASSERTSTATE( leaf );
  setLeafSelection( *leaf, LeafView::noSelection );
  _anchorOrder = 0;

  // remove anchor from current cursor position too
  leaf = (LeafView *) _current->view();
  IASSERTSTATE( leaf );
  setLeafSelection( *leaf, LeafView::noSelection );

  return *this;
}


//
// Clipboard Operations ---------------------------------------------
//

VEdit & VEdit::paste()
{
  IClipboard clipboard( this->handle() );

  if ( clipboard.hasText() )
    insertText( clipboard.text() );

  return *this;
}


//
// Item Manipulation ------------------------------------------------
//

VEdit & VEdit::insertText( const IString & string, Boolean checkOvertype )
{

  if ( string.length() )
  {
    // hold all formatting
    _holdFormatting = true;

    // support overtype mode
    if ( checkOvertype && _isOvertype )
    {
      if ( _anchor == NULL )
        _anchor = newCursorRightLeft( *_current, true );
    }

    // overwrite selection, if present
    removeSelection();

    // skip transient views
    skipTransients();

    // get the current leaf view and parent for item
    LeafView * leaf = (LeafView *) _current->view();

    // insert all text items
    SmartText text( string );
    unsigned n = text.numItems();
    for ( int i = 0; i < n; i++ )
      leaf->insertItem( text.createItem( i, _flowItem ) );

    // check if format is necessary
    checkForFormat();
  }

  return *this;
}


VEdit & VEdit::insertItem( Item * item )
{
  // hold all formatting
  _holdFormatting = true;
  // overwrite selection, if present
  removeSelection();
  // skip transient views
  skipTransients();
  // get the current leaf view
  LeafView * leaf = (LeafView *) _current->view();
  // insert the item
  leaf->insertItem( item );
  // check if format is necessary
  return checkForFormat();
}


// create a Push-Pop pair around the selected stuff
// if nothing is selected, create an empty Push-Pop pair
// if item is non-NULL, insert it after the Push
VEdit & VEdit::createGroup( Item * item )
{
  // hold all formatting
  _holdFormatting = true;

  // get cursor to first and last view
  ViewCursor * cursor1;
  ViewCursor * cursor2;
  skipTransients();
  if ( _anchor )
  {
    // there is a selection, use anchor point
    skipTransients( true );
    int order = _flow->orderViews( *_current->view(), *_anchor->view() );
    if ( order < 0 )
    {
      cursor1 = _current;
      cursor2 = _anchor;
    }
    else
    {
      cursor1 = _anchor;
      cursor2 = _current;
    }
  }
  else
  {
    // no selection, use current cursor as both first and last
    cursor1 = cursor2 = _current;
  }

  // get the leaf views
  LeafView * leaf1 = (LeafView *) cursor1->view();
  IASSERTSTATE( leaf1 );
  LeafView * leaf2 = (LeafView *) cursor2->view();
  IASSERTSTATE( leaf2 );

  // create Push/Pop pair
  PushItem * push = new PushItem( _flowItem );
  PopItem * pop = new PopItem( _flowItem, push );

  // insert the Push/Pop and the item, if provided
  leaf1->insertItem( push );
  if ( item )
    leaf1->insertItem( item );
  leaf2->insertItem( pop );

  // unselect region (otherwise need to extend selection to include new insertions)
  dropAnchor( false );

  // check if format is necessary
  return checkForFormat();
}


//
// Commands ---------------------------------------------------------
//

// remove the selected region (as specified by _anchor and _current)
// assume that _formatView == NULL upon entry
// in order to avoid _formatView being set to a deleted view, this
//   procedure will take control of the setting of _formatView such
//   that correct reformatting is done
// view outside of (*after*) the delete region may also be deleted if
//   they are orphaned (e.g., PopViews which have their PushView deleted)
VEdit & VEdit::removeSelection()
{
  // nothing to do if there is no selection
  if ( ! _anchor )
    return *this;

  // remove selection anchors from both cursors
  // but clear _formatView because anchors may both be removed
  removeAnchors();
  _formatView = NULL;

  // skip transient views
  skipTransients( false, false );
  skipTransients( true, false );

  // nothing to do if _anchor and _current point to same view (order=0)
  int order = _flow->orderViews( *_current->view(), *_anchor->view() );
  if ( ! order )
    return *this;

  // determine order of cursors
  ViewCursor * cursor1;
  ViewCursor * cursor2;
  if ( order < 0 )
  {
    cursor1 = _current;
    cursor2 = _anchor;
  }
  else
  {
    cursor1 = _anchor;
    cursor2 = _current;
  }

  // move _current back one from the first cursor
  // after deletion is done, _current will be advanced to next valid view
  // _current will be NULL if very first view is being deleted
  _current = newCursorRightLeft( *cursor1, false );
  Boolean isFormatSet = false;
  if ( _current )
  {
    // see if in same placed view as cursor1
    // if so, that placed view should be set for formatting
    LeafView * leaf = (LeafView *) cursor1->view();
    IASSERTSTATE( leaf );
    View * placed1 = placedFromLeaf( *leaf );
    leaf = (LeafView *) _current->view();
    IASSERTSTATE( leaf );
    View * placed = placedFromLeaf( *leaf );
    if ( placed1 == placed )
    {
      placed->clearFormatted();
      setFormatView( *placed );
      isFormatSet = true;
    }
  }

  // move second cursor back one position
  ViewCursor * endCursor = newCursorRightLeft( *cursor2, false );
  IASSERTSTATE( endCursor );
  delete cursor2;

  // remove the selected area (also deletes cursors)
  _flow->remove( cursor1, endCursor );
  _anchor = NULL;

  // move _current forward to next valid view
  // this may  not be the same as cursor2, since it may have been orphaned and deleted
  if ( _current )
  {
    ViewCursor * cursor = newCursorRightLeft( *_current, true );
    setCurrent( cursor );
  }
  else
  {
    // move to first leaf cursor
    _current = _flow->newLeafCursor( true );
  }
  skipTransients( false, false );

  // set format view to current if it isn't set yet
  if ( ! isFormatSet )
  {
    LeafView * leaf = (LeafView *) _current->view();
    IASSERTSTATE( leaf );
    View * placed = placedFromLeaf( *leaf );
    placed->clearFormatted();
    setFormatView( *placed );
  }

  // check if adjacent words need to be merged
  // need to pass a placedView cursor to checkForWordMerge
  LeafView * leaf = (LeafView *) _current->view();
  IASSERTSTATE( leaf );
  View * placed = placedFromLeaf( *leaf );
  OrderedViewCursor * placedCursor = _flow->newViewCursor( placed );
  IASSERTSTATE( placedCursor );
  _flow->checkForWordMerge( placedCursor );
  delete placedCursor;

  return *this;
}



//
// File Operations --------------------------------------------------
//

VEdit & VEdit::importFile()
{
  IFileDialog::Settings fdSettings;
  fdSettings.setOpenDialog();
  IFileDialog fileDlg( NULL, this, fdSettings );
  if ( fileDlg.pressedOK() )
  {
    // open file stream
    ifstream  ifs( fileDlg.fileName() );

    // copy to memory via string stream
    strstream ss;
    ifs >> ss.rdbuf();

    // insert entire file contents as an IString
    const IString string( ss.str() );
    insertText( string );
  }

  return *this;
}


//
// Diagnostic -------------------------------------------------------
//

void VEdit::dump( unsigned level )
{
  // dump item tree
  dumpItemNode( _flow->subject(), 0, level );

  // dump view tree
  dumpViewNode( _flow, 0, level );
}

// recursive function to dump Item tree
void VEdit::dumpItemNode( Item * item, unsigned indent, unsigned level )
{
  ITRACE_ALL( IString().center( indent )
            + item->asString()
            + IString(" [") + IString( (unsigned)item ) + IString("]") );
  if ( ++indent <= level )
  {
    ItemCursor * itemCursor = item->newCursor();
    forCursor( *itemCursor )
    {
      dumpItemNode( itemCursor->item(), indent, level );
    }
    delete itemCursor;
  }
}

// recursive function to dump View tree
void VEdit::dumpViewNode( View * view, unsigned indent, unsigned level )
{
  ITRACE_ALL( IString().center( indent )
            + view->asString() );
  if ( ++indent <= level )
  {
    ViewCursor * viewCursor = view->newCursor();
    forCursor( *viewCursor )
    {
      dumpViewNode( viewCursor->view(), indent, level );
    }
    delete viewCursor;
  }
}


