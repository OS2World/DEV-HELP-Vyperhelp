/***************************************************************************
 * File...... AttributeView.hpp
 * Author.... Mat
 * Date...... 4/17/97
 *
 * AttributeView is an icon which represents a change to a font attribute,
 * such as bold, italic or underline.
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/
#ifndef ATTRIBUTEVIEW_HPP
#define ATTRIBUTEVIEW_HPP


// TextEditor
#include "IconView.hpp"
class AttributeItem;


class AttributeView: public IconView
{
  public:
    // constructor
    AttributeView( AttributeItem * subject, View * owner );

    // from View
    virtual View::FormatChange format( Pen & pen );

    // from IBase
    virtual IString asString() const;

  private:
    // helper
    const AttributeView & updatePen( Pen & pen ) const;

    // data
    AttributeItem * _subject;
};



#endif

