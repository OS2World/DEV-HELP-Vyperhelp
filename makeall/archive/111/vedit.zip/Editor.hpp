/***************************************************************************
 * File...... Editor.hpp
 * Author.... Mat
 * Date...... 8/17/95
 *
 * Editor is the client window of the scrollable viewport.  It contains
 * one FlowView.  The FlowView is a composite view containing all of the
 * Views being edited.  Each View corresponds to an Item in the document.
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/
#ifndef EDITOR_HPP
#define EDITOR_HPP

// OpenClass
#include <icanvas.hpp>      // ICanvas
#include <ipainhdr.hpp>     // IPaintHandler
#include <ikeyhdr.hpp>      // IKeyboardHandler
#include <imoushdr.hpp>     // IMouseHandler
#include <itimer.hpp>       // ITimer

// Editor
#include "Kursor.hpp"
#include "Page.hpp"
#include "PlacedView.hpp"
#include "EditorCursor.hpp"
class VPort;
class ViewCursor;
class FlowItem;
class FlowView;
class LineView;
class Item;


class Editor:
  public ICanvas,
  public IPaintHandler,
  public IKeyboardHandler,
  public IMouseHandler
{
  public:
    // constructor
    Editor( unsigned long windowId, VPort *viewport, FlowItem * flow );
    ~Editor();

    // formatter
    void resize();
      // called by viewport when width changes
    void formatStartingAt( PlacedView & startingView );
      // format the editor, starting on the given view

    // used by EditorTrigger
    void flushInput();

    // used by EditorCursor
    void changeSelection( ViewCursor & cursor1, ViewCursor & cursor2 );
    void refreshSelection();

    // diagnostic
    void dump( unsigned level );

  protected:
    // IPaintHandler
    virtual Boolean paintWindow( IPaintEvent &event );

    // IKeyboardHandler
    virtual Boolean virtualKeyPress( IKeyboardEvent & event );
    virtual Boolean characterKeyPress( IKeyboardEvent & event );
    virtual Boolean key( IKeyboardEvent & event );

    // IMouseHandler
    virtual Boolean mouseClicked( IMouseClickEvent & event );
    virtual Boolean mousePointerChange( IMousePointerEvent & event );
    virtual Boolean mouseMoved( IMouseEvent & event );

  private:
    // kursor movement
    void moveKursorTopBottom( Boolean moveTop );
    void moveKursorHomeEnd( Boolean moveHome );
    void moveKursorUpDown( Boolean moveUp );
    void moveKursorRightLeft( Boolean moveRight, Boolean moveByWord );
    void adjustKursor();
    void positionKursor( Boolean setKursorPoint );
    void scrollToFit( ViewCursor & viewCursor );
    void scrollToFitLine( const LineView * lineView );

    // cursor and selection support
    void dropAnchor( Boolean wantAnchor );
    void resetSelection();
    void autoSelect( Boolean moveRight );

    // formatting helpers
    void format( PlacedView * startingView = 0 );
    void checkForFormat();
    void setFormatView( PlacedView & view );
    void showSelection( IRectangle & rect );
    void redraw( IRectangle & rect );
      // repaint the given region

    // mouse helpers
    void handleMouseMove( IMouseEvent & event, Boolean wantAnchor );
    void handleDoubleClick();

    // commands
    void importFile();
    void paste();
    void insertText( const IString & string, Boolean checkOvertype = false );
    void insertItem( Item * item );
    void createGroup( Item * item );
    void removeSelection();

    // diagnostic
    void dumpItemNode( Item * item, unsigned indent, unsigned level );
    void dumpViewNode( View * view, unsigned indent, unsigned level );

    // data
    Page            _page;
    VPort *         _viewport;
    FlowView *      _flow;
    FlowItem *      _flowItem;
    EditorCursor    _current;
    EditorCursor    _anchor;
    int             _anchorOrder;    // -1,0,1 to indicate order relative to _current
    unsigned        _holdFormatting; // >0 to hold formatting (during operations)
    PlacedView *    _formatView;     // lowest-numbered PlacedView requiring format
                                     //   (NULL for if formatting is not needed)
    Boolean         _isSelectionEnabled;  // true if selection updating is active
    EditorCursor    _beginChange;    // begin/end of area where selection has changed
    EditorCursor    _endChange;
    Kursor          _kursor;
    IPoint          _kursorPoint;
    Boolean         _isOvertype;
    Boolean         _isDragActive;
    IPoint          _mousePoint;     // position of last mouse click or drag
    ITimer          _timer;
    IString         _input;
    IReference<ITimerFn> _trigger;   // ITimer requires a REFERENCE to a timer function!
};

#endif
