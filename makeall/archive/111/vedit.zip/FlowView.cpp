/***************************************************************************
 * File...... FlowView.cpp
 * Author.... Mat
 * Date...... 2/6/96
 *
 * Implementation of FlowView
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/

// Standard C
#include <stdlib.h>

// OpenClass
#include <itrace.hpp>                 // ITRACE macros
#include <iexcept.hpp>                // IASSERT macros

// TextEditor
#include "OrderedItemCursor.hpp"
#include "FlowItem.hpp"
#include "WordItem.hpp"
#include "DrawPen.hpp"
#include "LineView.hpp"
#include "Editor.hpp"
#include "FlowView.hpp"



/***************************************************************************
 * Procedure.. FlowView::FlowView
 * Author..... Mat
 * Date....... 5/16/96
 *
 * The constructor creates a view for each corresponding Item in the subject
 * FlowItem.  A single LineView is created to "hold" all the views until
 * the first format is performed.
 *
 * Assume that the caller will force a reformat after creating the FlowView
 *
 * For now, assume there is only one FlowView and it is owned by a Editor.
 ***************************************************************************/
FlowView::FlowView( FlowItem * subject ):
    SubjectView( subject, 0 ),
    _editor( 0 )
{
  // create a single LineItem to hold them all
  LineView * line = new LineView( this );
  _lines.add( line );

  // add all of the subject's items to the _views list
  ItemCursor * itemCursor = subject->newCursor();
  forCursor( *itemCursor )
    _views.add( itemCursor->item()->newView( line ) );
  delete itemCursor;

  // set Line to include all views
  OrderedViewCursor viewCursor( _views );
  viewCursor.setToFirst();
  IASSERTSTATE( viewCursor.isValid() );
  line->setFirstView( &viewCursor, false );
  viewCursor.setToLast();
  IASSERTSTATE( viewCursor.isValid() );
  line->setLastView( &viewCursor );
}


/***************************************************************************
 * Procedure.. FlowView::newCursor
 * Author..... Mat
 * Date....... 5/16/96
 *
 * Return an OrderedViewCursor for iterating across all LineViews
 ***************************************************************************/
OrderedViewCursor * FlowView::newCursor()
{
  return new OrderedViewCursor( _lines );
}


/***************************************************************************
 * Procedure.. FlowView::draw
 * Author..... Mat
 * Date....... 10/2/97
 *
 * Draw any line in the zone.
 ***************************************************************************/
void FlowView::draw( DrawPen & pen, const IRectangle & zone )
{
  OrderedViewCursor cursor( _lines );

  // assume lines are equal to get a starting point
  Coord zoneMax = zone.maxY();
  Coord flowMax = _size.height();
  if ( zoneMax > flowMax )
    zoneMax = flowMax;
  IPosition start = _lines.numberOfElements() * ( flowMax - zoneMax ) / flowMax;
  if ( start < 1 )
    start = 1;
  IASSERTSTATE( start <= _lines.numberOfElements() );
  _lines.setToPosition( start, *cursor.cursor() );

  // back up if necessary, then draw the lines
  Boolean looking = true;
  Boolean ok;
  do
  {
    LineView * line = (LineView *) cursor.view();
    Coord lineBottom = line->position().y();
    if ( looking )
    {
      Coord lineTop = lineBottom + line->height();
      if ( lineTop < zoneMax && ! cursor.isFirst() )
      {
        ok = cursor.setToPrevious();
        IASSERTSTATE( ok );
      }
      else
        looking = false;
    }
    if ( ! looking )
    {
      if ( lineBottom < zoneMax )
        line->draw( pen, zone.movedBy( - line->position() ) );
      if ( lineBottom < zone.minY() )
        return;
      ok = cursor.setToNext();
    }
  } while ( ok );
}


/***************************************************************************
 * Procedure.. FlowView::dispatchNotificationEvent
 * Author..... Mat
 * Date....... 5/16/96
 *
 * Dispatch notifications received from the subject FlowItem.
 ***************************************************************************/
void FlowView::dispatchNotificationEvent( INotificationId id, const IEventData & event )
{
  if ( id == Item::insertItemId )
    insertViews( * (OrderedItemCursor *) (char *) event );
}


/***************************************************************************
 * Procedure.. FlowView::insertViews
 * Author..... Mat
 * Date....... 5/14/96
 *
 * itemCursor points to an Item which was newly added to the FlowItem
 * (subject).  This function creates Views for the item and any other new
 * ones that follow.  Rely on format() to do proper line-breaking.
 *
 * Assumes that Views never need to be appended to the end of the last
 * line, because there is always an EndItem which doesn't allow appending.
 ***************************************************************************/
void FlowView::insertViews( OrderedItemCursor & itemCursor )
{
  ViewSequence::Cursor sequenceCursor( _views );
    // cursor to the View immediately before the new Views
    // (invalid if new Views should be placed at front)
  LineView * line;
    // pointer to line where new views are being inserted
  enum {
    firstOnLine,
    midLine,
    lastOnLine
  } insertPosition;
    // where on the linethe new views will be inserted
  OrderedViewCursor viewCursor( _views );
    // used to locate the view nearest to the new Item(s)
  OrderedViewCursor lineCursor( _lines );
    // used to locate first line if needed
  View * firstViewInserted = NULL;
    // pointer to first View inserted
  Boolean found;

  // must have a valid cursor
  IASSERTPARM( itemCursor.isValid() );


  // GET CURSOR TO LAST UNCHANGED ITEM IN THE FLOW
  // (invalidate if itemCursor is first)
  OrderedItemCursor itemCursorBefore = itemCursor;
  itemCursorBefore.setToPrevious();


  // FIND VIEW CORRESPONDING TO LAST UNCHANGED ITEM
  if ( itemCursorBefore.isValid() )
  {
    // look for "item before" in current _views list
    Item * itemBefore = itemCursorBefore.item();
    forCursor( viewCursor )
    {
      PlacedView * view = (PlacedView *) viewCursor.view();
      if ( view->subject() == itemBefore )
      {
        // found last unchanged view, save a cursor
        sequenceCursor.copy( *viewCursor.cursor() );
        // get line
        line = (LineView *) view->parent();
        // check if last view in the line
        // (can't use LineView cursor.isLast(), because it considers LineEndViews too!)
        insertPosition = ( line->lastView()->view() == view )? lastOnLine: midLine;
        // move to next view to get the item after any new items
        viewCursor.setToNext();
        break;
      }
    }
    // must always find a corresponding view
    IASSERTSTATE( viewCursor.isValid() );
  }
  else
  {
    // no "item before" -- insert in front of first view
    viewCursor.setToFirst();
    // get pointer to first line
    found = lineCursor.setToFirst();
    IASSERTSTATE( found );
    line = (LineView *) lineCursor.view();
    insertPosition = firstOnLine;
    // sequenceCursor is invalid to indicate insert at front
  }


  // SAVE POINTER TO ITEM AFTER NEW ONES
  PlacedView * placed = (PlacedView *) viewCursor.view();
  Item * itemAfter = placed->subject();


  // INSERT ALL NEW ITEMS
  Item * item;
  View * view = NULL;
  while ( ( item = itemCursor.item() ) != itemAfter )
  {
    // create a view pointer
    view = item->newView( line );

    // save first view inserted
    if ( firstViewInserted == NULL )
      firstViewInserted = view;

    // add it to front or at the specified cursor
    // this also advances the cursor to the new view
    if ( sequenceCursor.isValid() )
      _views.addAsNext( view, sequenceCursor );
    else
      _views.addAsFirst( view, sequenceCursor );

    // reset line's first view if necessary
    if ( insertPosition == firstOnLine )
    {
      found = viewCursor.locate( view );
      IASSERTSTATE( found );
      line->setFirstView( &viewCursor, false );
      insertPosition = midLine;
    }

    // move to the next item
    if ( ! itemCursor.setToNext() )
      break;
  } /* endwhile */

  // reset line's last view if necessary
  if ( view != NULL && insertPosition == lastOnLine )
  {
    found = viewCursor.locate( view );
    IASSERTSTATE( found );
    line->setLastView( &viewCursor );
  }


  // RE-FORMAT, STARTING WITH THE FIRST VIEW
  if ( firstViewInserted )
    _editor->formatStartingAt( *(PlacedView *) firstViewInserted );
}


/***************************************************************************
 * FlowView::remove
 *
 * Remove the range of views specified.  Calls recursively into each View's
 * remove() function.  Both provided cursors are leaf views.
 ***************************************************************************/
unsigned FlowView::remove( ViewCursor * fromCursor, ViewCursor * toCursor )
{
  // assume that both cursors are provided
  IASSERTPARM( fromCursor );
  IASSERTPARM( toCursor );

  // find first and last line
  View * firstLine = locateDescendent( *fromCursor->view() );
  IASSERTSTATE( firstLine );
  View * lastLine = locateDescendent( *toCursor->view() );
  IASSERTSTATE( lastLine );
  // assume last line >= first line (no check done)

  // get a cursor to View before the first one removed
  // may need this cursor if we need to search for orphans
  View * firstView = firstLine->locateDescendent( *fromCursor->view() );
  IASSERTSTATE( firstView );
  OrderedViewCursor viewCursor( _views );
  Boolean found = viewCursor.locate( firstView );
  IASSERTSTATE( found );
  viewCursor.setToPrevious();

  // get cursor, starting with first line
  ViewCursor * lineCursor = firstLine->newCursorToThis();
  IASSERTSTATE( lineCursor );

  // use cursor to iterate through lines
  View * line;
  Boolean ok;
  unsigned orphanCount = 0;
  do
  {
    line = lineCursor->view();
    orphanCount += line->remove(
        line == firstLine? fromCursor: NULL,
        line == lastLine? toCursor: NULL );
    if ( line == lastLine )
      ok = false;
    else
      ok = lineCursor->setToNext();
  }
  while ( ok );

  // delete the cursor
  delete lineCursor;

  // search for orphans
  if ( orphanCount )
  {
    // if the view cursor is invalid, start at beginning
    if ( ! viewCursor.isValid() )
      viewCursor.setToFirst();
    // search for orphans and delete them
    while ( orphanCount && viewCursor.isValid() )
    {
      PlacedView * view = (PlacedView *) viewCursor.view();
      // increment cursor before deletion
      viewCursor.setToNext();
      // check for orphan
      if ( view->isOrphan() )
      {
        // delete the orphan item and view
        IASSERTSTATE( view->subject() );
        delete view->subject();
        orphanCount--;
        // check for word merge
        if ( viewCursor.isValid() )
        {
          view = (PlacedView *) viewCursor.view();
          if ( ! view->isOrphan() )
            checkForWordMerge( &viewCursor );
        }
      }
    }
  }

  // internal orphan search already done
  return 0;
}



/***************************************************************************
 * FlowView::checkForWordMerge
 *
 * Check to see if the given and the previous view are both CharViews in a
 * different word view. If so, the two words need to be combined into one,
 * and the given view is DELETED!
 * The given view is assumed to be a member of the flow's collection.
 * Return true if words were merged and cursor was setToNext().
 ***************************************************************************/
Boolean FlowView::checkForWordMerge( OrderedViewCursor * cursor )
{
  // get view
  IASSERTPARM( cursor );
  PlacedView * view = (PlacedView *) cursor->view();
  IASSERTSTATE( view );

  // check if item is a word
  Item * item = view->subject();
  if ( item && item->isWord() )
  {
    // now check if the previous view is also a Word
    // use internal cursor to avoid line boundaries and transient views
    OrderedViewCursor cursorPrevious( _views );
    Boolean found = cursorPrevious.locate( view );
    IASSERTSTATE( found );
    found = cursorPrevious.setToPrevious();
    if ( found )
    {
      PlacedView * viewPrevious = (PlacedView *) cursorPrevious.view();
      IASSERTSTATE( viewPrevious );
      // check if this item is a word, too
      Item * itemPrevious = viewPrevious->subject();
      if ( itemPrevious && itemPrevious->isWord() )
      {
        // merge the words!
        // first move the given cursor forward to avoid invalidation
        cursor->setToNext();
        // now merge the two words ("word" will delete itself)
        WordItem * word = (WordItem *)item;
        WordItem * wordPrevious = (WordItem *)itemPrevious;
        word->mergeWords( *wordPrevious );
        return true;
      }
    }
  }

  return false;
}



/***************************************************************************
 * Procedure.. FlowView::update
 * Author..... Mat
 * Date....... 6/18/96
 *
 * Handle notification from a child View which has changed its representation.
 * Update the display to reflect changes.
 ***************************************************************************/
void FlowView::update( View & childView )
{
  // initiate format starting at the given View (child of a LineView)
  _editor->formatStartingAt( (PlacedView &) childView );
}


/***************************************************************************
 * Procedure.. FlowView::newCorrelateCursor
 * Author..... Mat
 * Date....... 5/16/96
 *
 * Correlate a point by locating the correct line (y-position) and then
 * correlating x-position within that line.
 *
 * Could change to use a faster search (binary?)
 ***************************************************************************/
ViewCursor * FlowView::newCorrelateCursor( IPoint & point )
{
  OrderedViewCursor lineCursor( _lines );

  forCursor( lineCursor ) {
    View * line = lineCursor.view();
    Coord bottom = line->position().y();
    Coord top = bottom + line->extent();
    /// which side should be inclusive? both?
    if ( ( point.y() <= top ) && ( point.y() >= bottom ) ) {
      // found the correct line
      IPoint relativePoint = point - IPoint( 0, bottom );
      return line->newCorrelateCursor( relativePoint );
    } /* endif */
  } /* endfor */

  return NULL;
}


void FlowView::removeChild( View * view )
{
  _lines.remove( view );
}


void FlowView::removePlacedView( View * view )
{
  _views.remove( view );
}


int FlowView::orderViews( View & view1, View & view2 )
{
  // check for same view
  if ( &view1 == &view2 )
    return 0;

  // check if either view is "this"
  if ( &view1 == this)
    return -1;
  else if ( &view2 == this )
    return 1;

  // find both lines
  View * line1 = locateDescendent( view1 );
  IASSERTSTATE( line1 );
  View * line2 = locateDescendent( view2 );
  IASSERTSTATE( line2 );

  // if on the same line, pass the request down to the line
  if ( line1 == line2 )
    return line1->orderViews( view1, view2 );

  // otherwise find out which line is first
  return _lines.order( *line1, *line2 );
}


int FlowView::orderLines( LineView & line1, LineView & line2 )
{
  return _lines.order( line1, line2 );
}


// assumes both children are in its collection
// used by child LineViews to ask about View ordering
int FlowView::orderPlacedViews( View * view1, View * view2 )
{
  return _views.order( *view1, *view2 );
}


OrderedViewCursor * FlowView::newViewCursor( View * view )
{
  OrderedViewCursor * cursor = new OrderedViewCursor( _views );
  if ( view )
    cursor->locate( view );
  else
    cursor->setToFirst();
  return cursor;
}


IString FlowView::dumpString() const
{
  return debugString( "FlowView" );
}

