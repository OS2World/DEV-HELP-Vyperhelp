/***************************************************************************
 * File...... SpaceView.cpp
 * Author.... Mat
 * Date...... 5/7/96
 *
 * Implementation of SpaceView
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/

// OpenClass
#include <istring.hpp>      // IString

// TextEditor
#include "FormatPen.hpp"
#include "DrawPen.hpp"
#include "SpaceView.hpp"


SpaceView::SpaceView( Item * subject, View * parent ):
  PlacedView( subject, parent )
{}


PlacedView::FormatChange SpaceView::format( FormatPen & pen )
{
  // do default preparation and formatting
  FormatChange change = PlacedView::format( pen );

  // check for width change
  Coord oldWidth = _width;
  _width = pen.charWidth( ' ' );
  if ( oldWidth != _width )
    change = changeSize;

  return change;
}


void SpaceView::draw( DrawPen & pen, const IRectangle & zone )
{
  pen.drawChar( ' ' );
  pen.forward( _width );
}


IString SpaceView::dumpString() const
{
  return debugString( "SpaceView" );
}

