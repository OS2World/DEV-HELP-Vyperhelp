/***************************************************************************
 * File...... ItemSequence.hpp
 * Author.... Mat
 * Date...... 4/18/96
 *
 * Cursor for items nested within a FlowItem.
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/
#ifndef ITEMSEQUENCE_HPP
#define ITEMSEQUENCE_HPP


// OpenClass
#include <ieqseq.h>         // IEqualitySequence

// TextEditor
class Item;

class ItemSequence: public IEqualitySequence<Item*>
{
  public:
    // constructor
    ItemSequence( INumber numberOfElements = 100 );
    ~ItemSequence();

    // delete and remove
    void deleteAndRemove( IOrderedCursor<Item*> & cursor );
};


#endif

