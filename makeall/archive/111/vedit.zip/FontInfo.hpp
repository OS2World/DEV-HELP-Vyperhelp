/***************************************************************************
 * File...... FontInfo.hpp
 * Author.... Mat
 * Date...... 2/20/97
 *
 * Holds information about a font, including name, size and attributes.
 * Also has methods to convert to or from an IFont.
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/
#ifndef FONTINFO_HPP
#define FONTINFO_HPP

// OpenClass
#include <istring.hpp>
class IFont;
class IGraphicContext;


class FontInfo: public IBase
{
  public:
    // constructors
    FontInfo();
    FontInfo( const IFont & font );

    // comparison
    int operator==( const FontInfo & font ) const;
    int operator!=( const FontInfo & font ) const;

    // query functions
    const IString & name() const;
    unsigned long   pointSize() const;
    Boolean         isVector() const;
    Boolean         isBold() const;
    Boolean         isItalic() const;
    Boolean         isUnderline() const;

    // setter functions
    void setFont( const IString & name, unsigned long pointSize, Boolean isVector );
    void setBold( Boolean isBold );
    void setItalic( Boolean isItalic );
    void setUnderline( Boolean isUnderline );

    // IFont conversion
    IFont * newFont( IGraphicContext & context ) const;

    // diagnostic
    void            dumpMetrics( IGraphicContext & context ) const;
    virtual IString asString() const;

  private:
    // helpers
    void    removeVariants();
    Boolean addVariant( IString & name, const IString & variant, const IGraphicContext & context ) const;

    // data
    /// need font family? proportional/mono?
    IString       _name;        // empty string = default
    unsigned long _pointSize;   // 0 = default
    Boolean       _isVector;    // true for scalable vector fonts
    /// codepage?
    Boolean       _isBold;
    Boolean       _isItalic;
    Boolean       _isUnderline;
    /// use IBitFlag for flags?
};


// inline functions
#include "FontInfo.ipp"


#endif

