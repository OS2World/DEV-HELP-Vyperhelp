/***************************************************************************
 * File...... PenState.cpp
 * Author.... Mat
 * Date...... 1/3/97
 *
 * Implementation for PenState
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// TextEditor
#include "PenState.hpp"

int PenState::operator==( const PenState & state ) const
{
  return ( font == state.font );
}

