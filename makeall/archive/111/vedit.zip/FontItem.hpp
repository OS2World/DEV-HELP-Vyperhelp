/***************************************************************************
 * File...... FontItem.hpp
 * Author.... Mat
 * Date...... 2/4/97
 *
 * FontItem represents a change in font, using the IFont
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/
#ifndef FONTITEM_HPP
#define FONTITEM_HPP


// OpenClass
#include <istring.hpp>

// TextEditor
#include "Item.hpp"
class FontInfo;


class FontItem: public Item
{
  public:
    // constructor
    FontItem( Item * parent, const FontInfo & font );

    // accessor
    const IString & name() const;
    unsigned long   pointSize() const;
    Boolean         isVector() const;

    // from Item
    virtual View *  newView( View * parent );
    virtual IString dumpString() const;

  private:
    IString       _name;
    unsigned long _pointSize;
    Boolean       _isVector;
};


// inline functions
#include "FontItem.ipp"


#endif

