/***************************************************************************
 * File...... LeafView.hpp
 * Author.... Mat
 * Date...... 5/7/96
 *
 * LeafView adds functionality to the basic View to support the bottom
 * level "leaf" views.  These bottom level views are the ones cursored,
 * selected and manipulated by the user
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/
#ifndef LEAFVIEW_HPP
#define LEAFVIEW_HPP


// OpenClass
class IString;

// TextEditor
#include "View.hpp"


class LeafView: public View
{
  public:
    // constructor
    LeafView( Item * subject, View * owner );

    // commands
    virtual void insertItem( Item * item );
      // default works when subject is child of a FlowItem

    // from View
    virtual ViewCursor * newLeafCursor( const Boolean wantFirst );
    virtual FormatChange format( Pen & pen );
      // default saves x-position from pen point and checks for a control change
    virtual IPoint       position() const;
      // default returns (x,0)

  protected:
    Boolean    setPosition( Coord xPosition );

  private:
    Item *    _subject;
    Coord     _xPosition;
};


#endif

