/***************************************************************************
 * File...... VEdit.hpp
 * Author.... Mat
 * Date...... 8/17/95
 *
 * VEdit is the client window of the scrollable viewport.  It contains
 * one FlowView.  The FlowView is a composite view containing all of the
 * Views being edited.  Each View corresponds to an Item in the document.
 *
 * Copyright (C) 1995 MekTek
 ***************************************************************************/
#ifndef VEDIT_HPP
#define VEDIT_HPP

// OpenClass
#include <icanvas.hpp>      // ICanvas
#include <ipainhdr.hpp>     // IPaintHandler
#include <ikeyhdr.hpp>      // IKeyboardHandler
#include <imoushdr.hpp>     // IMouseHandler

// VEdit
#include "Kursor.hpp"
#include "Page.hpp"
#include "LeafView.hpp"
class VPort;
class ViewCursor;
class FlowItem;
class FlowView;
class LineView;
class Item;


class VEdit:
  public ICanvas,
  public IPaintHandler,
  public IKeyboardHandler,
  public IMouseHandler
{
  public:
    // constructor
    VEdit( unsigned long windowId, VPort *viewport, FlowItem * flow );
    ~VEdit();

    // formatter
    VEdit & resize();
      // called by viewport when width changes
    VEdit & formatStartingAt( View & startingView );
      // format the editor, starting on the given view

    // diagnostic
    void dump( unsigned level );

  protected:
    // IPaintHandler
    virtual Boolean paintWindow( IPaintEvent &event );

    // IKeyboardHandler
    virtual Boolean virtualKeyPress( IKeyboardEvent & event );
    virtual Boolean characterKeyPress( IKeyboardEvent & event );
    virtual Boolean key( IKeyboardEvent & event );

    // IMouseHandler
    virtual Boolean mouseClicked( IMouseClickEvent & event );
    virtual Boolean mousePointerChange( IMousePointerEvent & event );
    virtual Boolean mouseMoved( IMouseEvent & event );

  private:
    // kursor movement
    VEdit & moveKursorTopBottom( Boolean moveTop );
    VEdit & moveKursorHomeEnd( Boolean moveHome );
    VEdit & moveKursorUpDown( Boolean moveUp );
    VEdit & moveKursorRightLeft( Boolean moveRight );
    VEdit & adjustKursor();
    VEdit & positionKursor( Boolean setKursorPoint );
    VEdit & scrollToFit( ViewCursor & viewCursor );
    VEdit & scrollToFitLine( const LineView * lineView );

    // cursor support
    VEdit &      dropAnchor( Boolean wantAnchor );
    VEdit &      setCurrent( ViewCursor * cursor, Boolean updateSelection = true );
    VEdit &      setAnchor( ViewCursor * cursor, Boolean updateSelection = true );
    ViewCursor * newCursorRightLeft( ViewCursor & cursor, Boolean moveRight );
    Boolean      skipTransients( Boolean useAnchor = false, Boolean updateSelection = true );
    VEdit &      unskipTransients( Boolean useAnchor = false );

    // formatting helpers
    VEdit & format( View * startingView = NULL );
    VEdit & setLeafSelection( LeafView & leaf, LeafView::Selection selection );
    VEdit & removeAnchors();
    VEdit & checkForFormat( Boolean resetHold = true );
    VEdit & setFormatView( View & view );
    View *  placedFromLeaf( LeafView & leaf );
    VEdit & redraw( const IRectangle & rect );
      // repaint the given region

    // mouse helpers
    VEdit & handleMouseMove( IMouseEvent & event, Boolean wantAnchor );

    // commands
    VEdit & importFile();
    VEdit & paste();
    VEdit & insertText( const IString & string, Boolean checkOvertype = false );
    VEdit & insertItem( Item * item );
    VEdit & createGroup( Item * item );
    VEdit & removeSelection();

    // diagnostic
    void dumpItemNode( Item * item, unsigned indent, unsigned level );
    void dumpViewNode( View * view, unsigned indent, unsigned level );

    // data
    Page            _page;
    VPort *         _viewport;
    FlowView *      _flow;
    FlowItem *      _flowItem;
    ViewCursor *    _current;
    ViewCursor *    _anchor;
    int             _anchorOrder;    // -1,0,1 to indicate order relative to _current
    Boolean         _holdFormatting; // true to hold formatting (during operations)
    View *          _formatView;     // lowest-numbered "placed" view requiring format
                                     // (NULL for if formatting is not needed)
    Kursor          _kursor;
    IPoint          _kursorPoint;
    Boolean         _isOvertype;
    Boolean         _isDragActive;
    IPoint          _mousePoint;     // position of last mouse click or drag
};

#endif
