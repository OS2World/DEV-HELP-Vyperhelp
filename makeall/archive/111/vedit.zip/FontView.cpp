/***************************************************************************
 * File...... FontView.cpp
 * Author.... Mat
 * Date...... 2/4/97
 *
 * Implements the FontView.
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// TextEditor
#include "FontView.hpp"
#include "FontItem.hpp"
#include "FormatPen.hpp"
#include "DrawPen.hpp"


// static data
IGBitmap FontView::_bitmap( BMP_FONT );


FontView::FontView( FontItem * subject, View * parent ):
  IconView( subject, parent )
{}


PlacedView::FormatChange FontView::format( FormatPen & pen )
{
  FormatChange change = PlacedView::format( pen );
  pen.setFont( font()->name(), font()->pointSize(), font()->isVector() );
  return change;
}


void FontView::draw( DrawPen & pen, const IRectangle & zone )
{
  pen.setFont( font()->name(), font()->pointSize(), font()->isVector() );
  IconView::draw( pen, zone );
}


FontItem * FontView::font() const
{
  return (FontItem *) subject();
}


IString FontView::dumpString() const
{
  return debugString( IString( "FontView:" ) + font()->name() );
}

