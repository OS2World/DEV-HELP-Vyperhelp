/***************************************************************************
 * File...... Symbol.cpp
 * Author.... Mat
 * Date...... 3/27/97
 *
 * Implementation of Symbol.
 *
 * NOTE: This is not platform independent.  It uses PM calls.  It also
 * assumes that PM has been initialized for the current thread.  Also
 * assumes that the active code page is static and will not change during
 * the program's run.
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// OS/2
#define INCL_PM
#include <os2.h>

// OpenClass
#include <iexcept.hpp>      // exception macros
#include <itrace.hpp>       // ITRACE macros
#include <ithread.hpp>      // IThread
#include <igrafctx.hpp>     // IGraphicContext
#include <ifont.hpp>        // IFont

// TextEditor
#include "Symbol.hpp"


// static class data
unsigned long Symbol::_activeCodePage;

// constant flags for translation table (_xlat)
static const unsigned short _cpNone   = 0x0000; // if character should/can not be translated
static const unsigned short _cp850    = 0x0100; // if character comes from code page 850
static const unsigned short _cp437    = 0x0200; // if character comes from code page 437
static const unsigned short _cpApprox = 0x8000; // if tranlation is approximate (not preferred)


Symbol::Symbol( Identifier id ):
  _codePage( 0 ),
  _id( id )
{}


Symbol::Symbol( unsigned char ch, unsigned long codePage ):
  _codePage( 0 )
{
  if ( ! codePage )
    codePage = activeCodePage();

  // attempt to convert a char to a symbol id
  // if given code page was 437, try that first, otherwise 850
  Boolean found = searchForSymbol(
    codePage == 437? _cp437: _cp850,
    codePage == 437? 437: 850,
    ch, codePage );
  if ( ! found )
    found = searchForSymbol(
      codePage != 437? _cp850: _cp437,
      codePage != 437? 850: 437,
      ch, codePage );

  // can't find symbol -- save as CP/char pair
  if ( ! found )
  {
    _codePage = codePage;
    _ch = ch;
  }
}


Boolean Symbol::searchForSymbol(
  unsigned short tableFlag,
  unsigned long  tableCodePage,
  unsigned char  ch,
  unsigned long  fromCodePage )
{
  // convert char to table code page for search
  unsigned char wantChar = convert( ch, fromCodePage, tableCodePage );
  if ( wantChar == 0 )
    return false;

  // loop through table entries looking for a match
  for (int i = 0; i <= endOfList - startOfList; i++)
  {
    if ( _xlat[i] & tableFlag )
    {
      unsigned char tableChar = (unsigned char)(_xlat[i] & 0xff);
      if (tableChar == wantChar)
      {
        _id = Identifier(i + startOfList);
        return true;
      }
    }
  }

  return false;
}


// returns 0 if can't/shouldn't be converted
unsigned char Symbol::asChar( unsigned long codePage ) const
{
  if ( ! codePage )
    codePage = activeCodePage();

  unsigned long fromCodePage;
  unsigned char fromChar;
  if ( _codePage )
  {
    fromCodePage = _codePage;
    fromChar = _ch;
  }
  else
  {
    // get code page and char from ID via static table
    IASSERTSTATE( _id >= startOfList && _id <= endOfList );
    unsigned short x = _xlat[ _id - startOfList ];
    fromChar = (unsigned char)(x & 0xff);

    // first check for an exact code page match
    if ( codePage == 850 && ( x & _cp850 ) )
      return fromChar;
    if ( codePage == 437 && ( x & _cp437 ) )
      return fromChar;

    // next check for an available conversion
    if ( x & _cp850 )
      fromCodePage = 850;
    else if ( x & _cp437 )
      fromCodePage = 437;
    else
      return 0;  // no translation!
  }

  return convert( fromChar, fromCodePage, codePage );
}


/***************************************************************************
 * Procedure.. Symbol::setContextFont
 *
 * This is a workaround for a problem with the OpenClass library.  When
 * you use IGraphicContext::setFont directly, the code page will sometimes
 * get reset to 850 (depending on which font you are using).  This routine
 * forces the code page to remain at the active code page.  This program
 * assumes that the code page will not change throughout the run of the
 * program.
 ***************************************************************************/
void Symbol::setContextFont( IGraphicContext & context, IFont & font )
{
  // cheat and get a non-const pointer to the font's attributes
  PFATTRS pfattrs = (PFATTRS) font.fattrs();

  // set it to the active code page
  pfattrs->usCodePage = activeCodePage();

  // go ahead and call IGraphicContext
  context.setFont( font );
}


unsigned long Symbol::activeCodePage()
{
  // load active code page if it isn't already loaded
  if ( ! _activeCodePage )
    _activeCodePage = getActiveCodePage();

  // return the active code page
  return _activeCodePage;
}


unsigned long Symbol::getActiveCodePage()
{
  ULONG cp = WinQueryCp( IThread::current().messageQueue() );
  if ( ! cp )
    ITHROWGUIERROR( "WinQueryCp" );
  return cp;
}



unsigned char Symbol::convert(
  unsigned char ch,
  unsigned long fromCodePage,
  unsigned long toCodePage ) const
{
  // check for same code page
  if ( fromCodePage == toCodePage )
    return ch;

  // call PM to convert
  ITRACE_ALL( IString("Symbol::convert from ") + IString(fromCodePage) + IString(" to ") + IString(toCodePage) );
  unsigned char ch2 = WinCpTranslateChar(
      IThread::current().anchorBlock(),
      fromCodePage,
      ch,
      toCodePage );

  // ch2 = 0 if conversion failed, 0xff if no translation
  // return 0 if unable to convert
  return ( ch2 == 0 || ch2 == 0xff )? 0: ch2;
}


// translation table
// lower 8-bits is the unsigned char for a given symbol
// upper 8-bits is flags which tell which code page the char is from
unsigned short Symbol::_xlat[ endOfList - startOfList + 1 ] =
{
              _cp437 | _cp850 | 160, // aa
                       _cp850 | 181, // Aa
              _cp437 | _cp850 | 131, // ac
                       _cp850 | 182, // Ac
                       _cp850 | 239, // acute
              _cp437 | _cp850 | 132, // ae
              _cp437 | _cp850 | 142, // Ae
              _cp437 | _cp850 | 145, // aelig
              _cp437 | _cp850 | 146, // AElig
              _cp437 | _cp850 | 133, // ag
                       _cp850 | 183, // Ag
                       _cp437 | 224, // alpha
              _cp437 | _cp850 |  65, // Alpha (A)
              _cp437 | _cp850 |  38, // amp
              _cp437 | _cp850 |  94, // and
              _cp437 | _cp850 | 143, // angstrom
              _cp437 | _cp850 | 134, // ao
              _cp437 | _cp850 | 143, // Ao
              _cp437 | _cp850 |  39, // apos
              _cp437 | _cp850 |  42, // asterisk
                       _cp850 | 199, // At
                       _cp850 | 198, // at
              _cp437 | _cp850 |  64, // atsign
              _cp437 | _cp850 | 166, // aus
              _cp437 | _cp850 | 225, // Beta
              _cp437 | _cp850 | 219, // BOX
              _cp437 | _cp850 | 177, // box12
              _cp437 | _cp850 | 176, // box14
              _cp437 | _cp850 | 178, // box34
              _cp437 | _cp850 | 220, // BOXBOT
                       _cp437 | 221, // BOXLEFT
                       _cp437 | 222, // BOXRIGHT
              _cp437 | _cp850 | 223, // BOXTOP
              _cp437 | _cp850 |  92, // bslash
              _cp437 | _cp850 |   7, // bullet
                       _cp437 | 184, // bx0012
                       _cp437 | 183, // bx0021
              _cp437 | _cp850 | 187, // bx0022
                       _cp437 | 214, // bx0120
                       _cp437 | 210, // bx0121
              _cp437 | _cp850 | 205, // bx0202
                       _cp437 | 213, // bx0210
                       _cp437 | 209, // bx0212
              _cp437 | _cp850 | 201, // bx0220
              _cp437 | _cp850 | 203, // bx0222
                       _cp437 | 190, // bx1002
                       _cp437 | 181, // bx1012
                       _cp437 | 212, // bx1200
                       _cp437 | 208, // bx2101
                       _cp437 | 207, // bx1202
                       _cp437 | 198, // bx1210
                       _cp437 | 216, // bx1212
                       _cp437 | 189, // bx2001
              _cp437 | _cp850 | 188, // bx2002
              _cp437 | _cp850 | 186, // bx2020
                       _cp437 | 182, // bx2021
              _cp437 | _cp850 | 185, // bx2022
                       _cp437 | 211, // bx2100
                       _cp437 | 199, // bx2120
                       _cp437 | 215, // bx2121
              _cp437 | _cp850 | 200, // bx2200
              _cp437 | _cp850 | 202, // bx2202
              _cp437 | _cp850 | 204, // bx2220
              _cp437 | _cp850 | 206, // bx2222
              _cp437 | _cp850 | 193, // bxas
              _cp437 | _cp850 | 197, // bxcr
              _cp437 | _cp850 | 194, // bxde
              _cp437 | _cp850 | 196, // bxh
              _cp437 | _cp850 | 195, // bxle
              _cp437 | _cp850 | 192, // bxll
              _cp437 | _cp850 | 217, // bxlr
              _cp437 | _cp850 | 180, // bxri
              _cp437 | _cp850 | 218, // bxul
              _cp437 | _cp850 | 191, // bxur
              _cp437 | _cp850 | 179, // bxv
              _cp437 | _cp850 |  94, // caret
              _cp437 | _cp850 | 135, // cc
              _cp437 | _cp850 | 128, // Cc
  _cpApprox | _cp437 | _cp850 |  34, // cdq
              _cp437 | _cp850 | 175, // cdqf
                       _cp850 | 247, // cedil
                       _cp850 | 189, // cent
              _cp437 | _cp850 |  58, // colon
              _cp437 | _cp850 |  44, // comma
                       _cp850 | 184, // copy
  _cpApprox | _cp437 | _cp850 |  39, // csq
                       _cp850 | 207, // curren
              _cp437 | _cp850 |  25, // darrow
  _cpApprox | _cp437 | _cp850 |  45, // dash
              _cp437 | _cp850 | 248, // degree
                       _cp437 | 235, // delta
              _cp437 | _cp850 | 246, // divide
              _cp437 | _cp850 |  36, // dollar
              _cp437 | _cp850 | 250, // dot
              _cp437 | _cp850 | 144, // Ea
              _cp437 | _cp850 | 130, // ea
              _cp437 | _cp850 | 136, // ec
                       _cp850 | 210, // Ec
              _cp437 | _cp850 | 137, // ee
                       _cp850 | 211, // Ee
              _cp437 | _cp850 | 138, // eg
                       _cp850 | 212, // Eg
  _cpApprox | _cp437 | _cp850 |  45, // emdash
              _cp437 | _cp850 |  45, // endash
                       _cp437 | 238, // epsilon
              _cp437 | _cp850 |  61, // eq
                       _cp850 | 209, // ETH
                       _cp850 | 208, // eth
              _cp437 | _cp850 |  12, // female
              _cp437 | _cp850 | 159, // fnof
              _cp437 | _cp850 | 171, // frac12
              _cp437 | _cp850 | 172, // frac14
                       _cp850 | 243, // frac34
                       _cp437 | 226, // Gamma
                       _cp437 | 242, // ge
              _cp437 | _cp850 |  96, // grave
              _cp437 | _cp850 |  62, // gt
              _cp437 | _cp850 | 127, // house
              _cp437 | _cp850 |  45, // hyphen
              _cp437 | _cp850 | 161, // ia
                       _cp850 | 214, // Ia
              _cp437 | _cp850 | 140, // ic
                       _cp850 | 215, // Ic
                       _cp437 | 240, // identical
              _cp437 | _cp850 | 139, // ie
                       _cp850 | 216, // Ie
              _cp437 | _cp850 | 141, // ig
                       _cp850 | 222, // Ig
                       _cp437 | 236, // infinity
                       _cp437 | 245, // intbot
                       _cp437 | 239, // intersect
                       _cp437 | 244, // inttop
              _cp437 | _cp850 | 173, // inve
              _cp437 | _cp850 | 168, // invq
              _cp437 | _cp850 |  17, // lahead
              _cp437 | _cp850 |  27, // larrow
              _cp437 | _cp850 | 123, // lbrace
              _cp437 | _cp850 |  91, // lbracket
                       _cp437 | 243, // le
              _cp437 | _cp850 | 170, // lnot
                       _cp437 | 169, // lnotrev
              _cp437 | _cp850 | 124, // lor
              _cp437 | _cp850 |  40, // lpar
              _cp437 | _cp850 | 156, // Lsterling
              _cp437 | _cp850 |  60, // lt
                       _cp850 | 238, // macr
              _cp437 | _cp850 |  11, // male
              _cp437 | _cp850 | 230, // micro
              _cp437 | _cp850 |  45, // minus
  _cpApprox | _cp437 | _cp850 |  32, // mspace
              _cp437 | _cp850 | 230, // mu
                       _cp437 | 247, // nearly
  _cpApprox | _cp437 | _cp850 |  32, // nspace
              _cp437 | _cp850 | 164, // nt
              _cp437 | _cp850 | 165, // Nt
              _cp437 | _cp850 |  35, // numsign
              _cp437 | _cp850 | 162, // oa
                       _cp850 | 224, // Oa
              _cp437 | _cp850 | 147, // oc
                       _cp850 | 226, // Oc
  _cpApprox | _cp437 | _cp850 |  34, // odq
              _cp437 | _cp850 | 174, // odqf
              _cp437 | _cp850 | 148, // oe
              _cp437 | _cp850 | 153, // Oe
              _cp437 | _cp850 | 149, // og
                       _cp850 | 227, // Og
                       _cp850 | 157, // Oslash
                       _cp850 | 155, // oslash
  _cpApprox | _cp437 | _cp850 |  39, // osq
                       _cp850 | 229, // Ot
                       _cp850 | 228, // ot
              _cp437 | _cp850 | 167, // ous
                       _cp850 | 244, // para
              _cp437 | _cp850 |  46, // per
              _cp437 | _cp850 |  37, // percent
                       _cp437 | 237, // phi
                       _cp437 | 232, // Phi
                       _cp437 | 227, // pi
              _cp437 | _cp850 |  43, // plus
              _cp437 | _cp850 | 241, // plusmin
              _cp437 | _cp850 |  34, // quot
              _cp437 | _cp850 |  16, // rahead
              _cp437 | _cp850 |  26, // rarrow
  _cpApprox | _cp437 | _cp850 |  32, // rbl
              _cp437 | _cp850 | 125, // rbrace
              _cp437 | _cp850 |  93, // rbracket
                       _cp850 | 169, // reg
  _cpApprox | _cp437 | _cp850 |  45, // rhy
              _cp437 | _cp850 |  41, // rpar
                       _cp850 | 245, // sect
              _cp437 | _cp850 |  59, // semi
                      _cpNone |   0, // shy
                       _cp437 | 229, // sigma
                       _cp437 | 228, // Sigma
  _cpApprox | _cp437 | _cp850 | 126, // similar
              _cp437 | _cp850 |  47, // slash
                       _cp850 | 221, // splitvbar
              _cp437 | _cp850 | 254, // sqbul
                       _cp437 | 251, // sqrt
                       _cp850 | 251, // sup1
              _cp437 | _cp850 | 253, // sup2
                       _cp850 | 252, // sup3
                       _cp437 | 252, // supn
              _cp437 | _cp850 | 225, // szlig
                       _cp437 | 231, // tau
                       _cp437 | 233, // Theta
                       _cp850 | 232, // THORN
                       _cp850 | 231, // thorn
              _cp437 | _cp850 | 126, // tilde
                       _cp850 | 158, // times
              _cp437 | _cp850 | 163, // ua
                       _cp850 | 233, // Ua
              _cp437 | _cp850 |  24, // uarrow
              _cp437 | _cp850 | 150, // uc
                       _cp850 | 234, // Uc
              _cp437 | _cp850 | 129, // ue
              _cp437 | _cp850 | 154, // Ue
              _cp437 | _cp850 | 151, // ug
                       _cp850 | 235, // Ug
                       _cp850 | 249, // uml
              _cp437 | _cp850 |  95, // us
              _cp437 | _cp850 | 124, // vbar
              _cp437 | _cp850 |  33, // xclm
                       _cp850 | 237, // Ya
                       _cp850 | 236, // yacute
              _cp437 | _cp850 | 152, // ye
                       _cp850 | 190  // yen
};


