/***************************************************************************
 * File...... Item.hpp
 * Author.... Mat
 * Date...... 2/1/96
 *
 * Item holds all information about the logical component of the item.
 * The corresponding View holds visual info.
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/
#ifndef ITEM_HPP
#define ITEM_HPP

// OpenClass
#include <ievtdata.hpp>     // IEventData
#include <inotify.hpp>      // INotificationId

// TextEditor
class View;
class SubjectView;
class ItemCursor;


class Item
{
  public:
    // CONSTRUCTOR
    Item( Item * parent = 0 );
    virtual ~Item();

    // RELATIONSHIPS
    Item * parent() const;
    virtual void change();
      // called when a child has been changed
    virtual ItemCursor * newCursor();
    virtual View *       newView( View * parent ) = 0;
    virtual void         removeChild( Item * item );

    // CLASS IDENTIFICATION
    virtual Boolean isWord() const;
      // returns true for WordItem, default returns true

    // PROPERTIES
    /// read-only, etc

    // MANIPULATION
    /// virtual void select( Boolean front ) {}
    /// virtual Boolean move( Boolean forward ) { return false; }
    /// virtual Boolean remove( Boolean behind ) { return true; }
    /// split word into 2 portions
    /// source: user input, glossary term, dictionary, etc...

    // NOTIFICATION SUPPORT
    // subset of full INotification support (too expensive for now)
    // handles only one observer!
    void notifyObservers( INotificationId id, const IEventData & event = IEventData() );
    void addObserver( SubjectView & view );
    static const INotificationId insertItemId;
      // IEventData( OrderedItemCursor * cursorToFirstNewItem )
    static const INotificationId deleteId;

    // STORAGE
    // read, write for persistent storage

    // DEBUGGING
    virtual IString dumpString() const = 0;

  private:
    Item *        _parent;
    SubjectView * _observer;
};


// inline functions
#include "Item.ipp"


#endif

