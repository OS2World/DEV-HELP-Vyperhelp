/***************************************************************************
 * File...... AttributeView.cpp
 * Author.... Mat
 * Date...... 4/17/97
 *
 * Implements the AttributeView
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// TextEditor
#include "AttributeView.hpp"
#include "AttributeItem.hpp"
#include "Pen.hpp"


AttributeView::AttributeView( AttributeItem * subject, View * owner ):
  IconView(
    ISystemBitmapHandle(
      subject->type() == AttributeItem::bold? ISystemBitmapHandle::maximizeButton:
      subject->type() == AttributeItem::italic? ISystemBitmapHandle::restoreButton:
      ISystemBitmapHandle::minimizeButton ),
    subject,
    owner ),
  _subject( subject )
{}


View::FormatChange AttributeView::format( Pen & pen )
{
  FormatChange change = IconView::format( pen );
  updatePen( pen );
  return change;
}


const AttributeView & AttributeView::updatePen( Pen & pen ) const
{
  switch ( _subject->type() )
  {
    case AttributeItem::bold:
      pen.setBold( _subject->isEnabled() );
      break;
    case AttributeItem::italic:
      pen.setItalic( _subject->isEnabled() );
      break;
    case AttributeItem::underline:
      pen.setUnderline( _subject->isEnabled() );
      break;
  }

  return *this;
}


IString AttributeView::asString() const
{
  return debugString( IString( "AttributeView:" ) + IString(_subject->type()) + IString(_subject->isEnabled()) );
}

