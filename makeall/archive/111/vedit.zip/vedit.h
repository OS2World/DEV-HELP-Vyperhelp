#ifndef VEDIT_H
#define VEDIT_H

// bitmap resource IDs
#include "vydit.h"

// window IDs
#define WND_MAIN             0x1000         // main frame window id
#define WND_PAGE             0x1002         // editor window id

#endif
