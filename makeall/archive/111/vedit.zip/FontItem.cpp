/***************************************************************************
 * File...... FontItem.cpp
 * Author.... Mat
 * Date...... 2/4/97
 *
 * Implementation of FontItem
 *
 * Copyright (C) 1997 MekTek
 ***************************************************************************/

// TextEditor
#include "FontInfo.hpp"
#include "FontItem.hpp"
#include "FontView.hpp"


FontItem::FontItem( Item * parent, const FontInfo & font ):
    Item( parent ),
    _name( font.name() ),
    _pointSize( font.pointSize() ),
    _isVector( font.isVector() )
{}


View * FontItem::newView( View * parent )
{
  return new FontView( this, parent );
}


IString FontItem::dumpString() const
{
  return IString( "FontItem " ) + _name;
}

