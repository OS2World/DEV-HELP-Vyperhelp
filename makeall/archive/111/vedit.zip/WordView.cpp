/***************************************************************************
 * File...... WordView.cpp
 * Author.... Mat
 * Date...... 5/2/96
 *
 * Implementation of WordView.
 *
 * _subwidths holds the cumulative width of each substring (1,n).
 * _length holds the number of characters in the word.
 *
 * Copyright (C) 1996 MekTek
 ***************************************************************************/

// OpenClass
#include <iexcept.hpp>                // IASSERT macros
#include <igstring.hpp>               // IGString
#include <ifont.hpp>                  // IFont
#include <igrect.hpp>                 // IGRectangle

// TextEditor
#include "DrawPen.hpp"
#include "FormatPen.hpp"
#include "FlowView.hpp"
#include "OrderedViewCursor.hpp"
#include "WordView.hpp"

//#define DRAW_TEXT_BOX
//#define DRAW_FONT_BOX


WordView::WordView( WordItem * subject, View * parent ):
    PlacedView( subject, parent ),
    _subwidths( 0 ),
    _length( 0 ),
    _lengthChanged( false ),
    _cursorSet( 0 )
{}


WordView::~WordView()
{
  delete[] _subwidths;
}


// 0-based index
Coord WordView::charOffset( const unsigned index ) const
{
  IASSERTSTATE( ! _lengthChanged );
  IASSERTPARM( index < _length );
  return index? _subwidths[index-1]: 0;
}


// 0-based index
Coord WordView::charWidth( const unsigned index ) const
{
  IASSERTSTATE( ! _lengthChanged );
  IASSERTPARM( index < _length );
  Coord width = _subwidths[index];
  if ( index )
    width -= _subwidths[index-1];
  return width;
}


// index is a 0-based index into the WordItem's string where the new item
// should be inserted
void WordView::insertItemAtChar( Item * item, const unsigned index )
{
  IASSERTPARM( index < _length );
  word()->insertItem( item, index );
}


WordViewCursor * WordView::newCursor()
{
  WordViewCursor * cursor = new WordViewCursor( this );
  Boolean ok = _cursorSet.add( cursor );
  IASSERTSTATE( ok );
  return cursor;
}


void WordView::cursorDeleted( WordViewCursor * cursor )
{
  Boolean ok = _cursorSet.remove( cursor );
  IASSERTSTATE( ok );
}


// check only for x-position
ViewCursor * WordView::newCorrelateCursor( IPoint & point )
{
  // can't be called while in a changed state
  IASSERTSTATE( ! _lengthChanged );

  // get a cursor
  WordViewCursor * cursor = newCursor();
  cursor->setToFirst();
  IASSERTSTATE( cursor->isValid() );

  // find the character which holds the x-position
  Coord x = point.x();
  int i = 0;
  while ( ( i < _length - 1 ) && ( x >= _subwidths[i] ) )
  {
    // move to next character
    i++;
    cursor->setToNext();
    IASSERTSTATE( cursor->isValid() );
  }

  // get pointer to the CharView
  View * view = cursor->view();

  // get correlation point from sub-view
  IPoint relativePoint = point - view->position();
  ViewCursor * result = view->newCorrelateCursor( relativePoint );

  // clean up and return result
  delete cursor;
  return result;
}


// revert to default View handling
// (override PlacedView)
ViewCursor * WordView::newLeafCursor( const Boolean wantFirst )
{
  return View::newLeafCursor( wantFirst );
}


int WordView::orderViews( View & view1, View & view2 )
{
  // assume Line already checked for same view
  IASSERTSTATE( &view1 != &view2 )

  // check if either view is "this"
  if ( &view1 == this)
    return -1;
  else if ( &view2 == this )
    return 1;

  // get CharView pointers to children
  CharView & char1 = (CharView &) view1;
  CharView & char2 = (CharView &) view2;

  // return result of comparison
  return (int)char1.index() - (int)char2.index();
}


PlacedView::FormatChange WordView::format( FormatPen & pen )
{
  const IString & string = word()->string();

  // get font metrics
  Coord oldHeight = _height;
  Coord oldDescent = _descent;
  _height = pen.maxAscender();
  _descent = pen.maxDescender();

  // get all word subwidths, 1, 1-2, 1-3, etc
  Coord oldWidth = width();
  unsigned oldLength = _length;
  _length = string.length();
  if ( _length != oldLength || _lengthChanged )
  {
    delete[] _subwidths;
    _subwidths = new Coord[_length];
  }
  _lengthChanged = false;
  Coord newWidth = 0;
  for ( unsigned i = 1; i <= _length; i++ )
  {
    /// charWidth doesn't properly handle DBCS!
    _subwidths[i-1] = ( newWidth += pen.charWidth( string[i] ) );
  }

  // call default formatting to check for change
  FormatChange change = PlacedView::format( pen );

  // check for size change
  if ( change < changeSize )
  {
    Boolean sizeChange = ( _height != oldHeight
                        || _descent != oldDescent
                        || newWidth != oldWidth );
    if ( sizeChange )
      change = changeSize;
  }

  /// what if text changed, but not size??

  return change;
}


/***************************************************************************
 * Procedure.. WordView::draw
 * Author..... Mat
 * Date....... 2/27/97
 *
 * NOTE: We should be able to draw more than one character at a time, but
 * I found that IGString would not space the characters as determined by
 * the font's charWidths.  It would sometimes add and sometimes subtract
 * space within a word.  Drawing character-by-character is less efficient,
 * but it lets us easily handle selection anchor points, and drawing of
 * partial words based on the repaint zone.
 ***************************************************************************/
void WordView::draw( DrawPen & pen, const IRectangle & zone )
{
  // can't be called while in a changed state
  IASSERTSTATE( ! _lengthChanged );

  // draw the string
  pen.drawString( word()->string() );

#ifdef DRAW_TEXT_BOX
  // draw graphic text box
  {
    IGString gstring( word()->string() );
    IRectangle rect(
        pen.baseline() - IPoint( 0, _descent ),
        gstring.boundingRect( pen.context() ).size() );
    IGRectangle grect( rect );
    IGraphicBundle bundle;
    bundle.setDrawOperation( IGraphicBundle::frame );
    bundle.setPenColor( IColor( IColor::red ) );
    grect.setGraphicBundle( bundle );
    grect.drawOn( pen.context() );
  }
#endif

#ifdef DRAW_FONT_BOX
  // draw font box
  {
    IFont * font = pen.state().font.newFont( pen.context() );
    IGraphicBundle bundle;
    bundle.setDrawOperation( IGraphicBundle::frame );
    bundle.setPenColor( IColor( IColor::blue ) );
    IRectangle rect( pen.baseline() - IPoint( 0, _descent ), ISize() );
    IGRectangle grect;
    grect.setGraphicBundle( bundle );
    for ( int i = 1; i <= _length ; i++ )
    {
      ISize size( font->textWidth( word()->string().subString( i, 1 ) ),
          font->maxAscender() + font->maxDescender() );
      rect.sizeTo( size );
      grect.setEnclosingRect( rect );
      grect.drawOn( pen.context() );
      rect.moveBy( IPoint( size.width(), 0 ) );
    }
    delete font;
  }
#endif

  // move pen ahead
  pen.forward( width() );
}


// assume the cursors are both for CharView children
// also delete the cursors if they are non-NULL
unsigned WordView::remove( ViewCursor * fromCursor, ViewCursor * toCursor )
{
  unsigned index1, index2;

  // get starting index for delete (convert to 1-based)
  if ( fromCursor )
  {
    CharView * charView = (CharView *) fromCursor->view();
    IASSERTSTATE( charView->parent() == this );
    index1 = charView->index() + 1;
    delete fromCursor;
  }
  else
  {
    index1 = 1;
  }

  // get ending index for delete (convert to 1-based)
  if ( toCursor )
  {
    CharView * charView = (CharView *) toCursor->view();
    IASSERTSTATE( charView->parent() == this );
    index2 = charView->index() + 1;
    delete toCursor;
  }
  else
  {
    index2 = _length;
  }

  // delete the entire WordItem if full range is selected
  if ( index1 == 1 && index2 == _length )
  {
    delete word();
    return 0;
  }

  // otherwise tell the WordItem to delete text
  word()->deleteText( index1, index2 );
  return 0;
}


/***************************************************************************
 * Procedure.. WordView::dispatchNotificationEvent
 * Author..... Mat
 * Date....... 5/16/96
 *
 * Dispatch notifications received from the subject WordItem.
 * Since children (CharView) are created on the fly, no need to create them here
 ***************************************************************************/
void WordView::dispatchNotificationEvent( INotificationId id, const IEventData & event )
{
  if ( id == Item::insertItemId )
  {
    // refresh the display
    parent()->update( *this );
    return;
  }

  if ( id == WordItem::insertCharsId
    || id == WordItem::deleteCharsId
    || id == WordItem::mergeWordsId )
  {
    // update length
    // convert to index so that updateIndex can be used
    unsigned index = _length + 1;
    Boolean changed = updateIndex( index, id, event );
    if ( changed )
    {
      _length = index - 1;
      _lengthChanged = true;
    }

    // update all cursor indexes
    WordViewCursorSet::Cursor setCursor( _cursorSet );
    forCursor( setCursor )
    {
      WordViewCursor * cursor = setCursor.element();
      index = cursor->index();
      if ( updateIndex( index, id, event ) )
        cursor->setIndex( index );
    }

    // special handling for merge: move cursors to previous word
    if ( id == WordItem::mergeWordsId )
    {
      // find the previous View (it should be a WordView)
      /// this code should be generalized somewhere
      /// it makes a lot of assumptions here
      View * line = parent();
      IASSERTSTATE( line );
      FlowView * flow = (FlowView *) line->parent();
      IASSERTSTATE( flow );
      OrderedViewCursor * cursor = flow->newViewCursor( this );
      IASSERTSTATE( cursor );
      Boolean ok = cursor->setToPrevious();
      IASSERTSTATE( ok );
      WordView * sibling = (WordView *) cursor->view();
      IASSERTSTATE( sibling );
      IASSERTSTATE( sibling->subject() );
      IASSERTSTATE( sibling->subject()->isWord() );
      delete cursor;

      // reassign cursors to the sibling word
      sibling->_cursorSet.addAllFrom( _cursorSet );
      forCursor( setCursor )
        setCursor.element()->setWord( sibling );
    }
    return;
  }

  // default: pass to parent class for handling
  SubjectView::dispatchNotificationEvent( id, event );
}


/***************************************************************************
 * Procedure.. WordView::updateIndex
 * Author..... Mat
 * Date....... 3/4/97
 *
 * Given a notification event and a reference to an index, update the
 * index based on the event.   Return true if the index was changed.
 ***************************************************************************/
Boolean WordView::updateIndex( unsigned & index, INotificationId id, const IEventData & event )
{
  if ( id == WordItem::insertCharsId )
  {
    // update index based on inserted text
    unsigned insertionIndex = event.lowNumber();
    unsigned insertionLength = event.highNumber();
    if ( index > insertionIndex )
    {
      index += insertionLength;
      return true;
    }
  }
  else if ( id == WordItem::deleteCharsId )
  {
    // update index based on deleted text
    unsigned firstIndex = event.lowNumber();
    unsigned lastIndex = event.highNumber();
    IASSERTSTATE( firstIndex <= lastIndex );
    if ( index > firstIndex )
    {
      if ( index > lastIndex )
        index -= ( lastIndex - firstIndex + 1 );
      else
        index = min( firstIndex, length() );
      return true;
    }
  }
  else if ( id == WordItem::mergeWordsId )
  {
    unsigned previousLength = event;
    // if index is valid, offset it by the previous word's former length
    if ( index )
    {
      index += previousLength;
      return true;
    }
  }

  return false;
}


WordItem * WordView::word()
{
  return (WordItem *) subject();
}


IString WordView::dumpString() const
{
  const WordItem * word = (const WordItem *) subject();
  return debugString( IString( "WordView:" ) + word->string() );
}

